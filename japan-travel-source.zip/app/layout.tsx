import { CurrencyProvider } from "@/components/CurrencyProvider";
import type { Metadata } from "next";
import "leaflet/dist/leaflet.css";
import "./globals.css";
export const metadata:Metadata={title:"旅日 · 日本旅游攻略与行程规划",description:"探索东京、京都、大阪、北海道和冲绳，拖拽规划日本行程，查看地图、预算与出行清单。",robots:{index:false,follow:false}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body><CurrencyProvider>{children}</CurrencyProvider></body></html>;}
