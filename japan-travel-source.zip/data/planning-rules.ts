/** Conservative planning windows, not live opening or railway data. */
export const cityOrder = ['东京','镰仓','箱根','京都','奈良','神户','大阪'] as const;
export type PlanningCity = typeof cityOrder[number];
export const defaultStays: Record<PlanningCity,number> = {东京:5,镰仓:1,箱根:0,京都:4,奈良:1,大阪:3,神户:0};
export const windows:Record<string,[number,number]> = {
 'sensoji':[420,1020], 'skytree':[600,1200], 'akihabara':[660,1200], 'shibuya-sky':[600,1290], 'meiji':[420,960], 'harajuku':[660,1200], 'kabukicho':[1020,1320], 'godzilla':[1020,1320], 'suntory':[1080,1320], 'nishiki':[600,1020], 'nijo':[525,960], 'kiyomizu':[360,1080], 'osaka-castle':[540,1050], 'shinsaibashi':[600,1260], 'kuromon':[540,1080], 'kamakura-buddha':[480,1020], 'hasedera':[480,960], 'todaiji':[480,1020], 'hakone':[540,960], 'hakone-onsen':[900,1260], 'kobe-kitano':[600,1020],
};
export const transitRules: Record<string,{minutes:number;yen:number;mode:string}> = {
 '东京|京都':{minutes:240,yen:14500,mode:'新干线＋车站接驳（非实时，含候车缓冲）'},
 '东京|镰仓':{minutes:100,yen:1000,mode:'JR＋当地接驳'},
 '东京|箱根':{minutes:150,yen:3000,mode:'小田急或 JR＋登山交通'},
 '镰仓|箱根':{minutes:150,yen:2500,mode:'JR 经小田原＋登山交通'},
 '镰仓|京都':{minutes:270,yen:14500,mode:'JR 经小田原＋新干线'},
 '箱根|京都':{minutes:240,yen:13500,mode:'登山交通＋小田原新干线'},
 '京都|奈良':{minutes:90,yen:800,mode:'JR / 近铁＋车站接驳'},
 '京都|大阪':{minutes:75,yen:600,mode:'JR 新快速＋车站接驳'},
 '奈良|大阪':{minutes:75,yen:800,mode:'JR / 近铁＋车站接驳'},
 '奈良|神户':{minutes:130,yen:1300,mode:'近铁 / JR 经大阪＋车站接驳'},
 '京都|神户':{minutes:100,yen:1200,mode:'JR 新快速＋车站接驳'},
 '大阪|神户':{minutes:75,yen:600,mode:'JR / 阪急＋车站接驳'},
};
export const ruleSources = [{name:'二条城开放与御殿休止日',url:'https://nijo-jocastle.city.kyoto.lg.jp/guide/annai/',checkedAt:'2026-11-01'}];
