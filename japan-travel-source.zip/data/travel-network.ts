// Timings and amounts are planning allowances, not confirmed 2027 departures or fares.
export const travelNetwork=[
{title:'羽田机场 → 御徒町',from:'羽田实际抵达航站楼',to:'JR御徒町',line:'首班京急→品川→JR；或单轨→滨松町→JR',time:'铁路约50–80分钟，另加等首班、入境和步行',yen:1000,changes:'1次',booking:'普通列车一般现场购票；首班与航站楼出入口再核',ic:'Suica／ICOCA支持区间可用；不把机场停留视为酒店入住',url:'https://www.haneda-tokyo-access.com/en/haneda-airport/nightandmorning.html'},
{title:'新宿 ⇄ 河口湖',from:'Busta新宿4楼',to:'河口湖站',line:'富士五湖高速巴士；铁路可比较富士回游',time:'巴士单程约1小时45分–3小时，堵车另留',yen:6000,changes:'巴士直达；御徒町→新宿及当地巴士另接',booking:'往返巴士待预订，提前查发售日；铁路特急券另购',ic:'预订巴士不能仅刷普通交通卡；湖区当地巴士按运营商规则',url:'https://bus.fujikyu.co.jp/en/highway/fujisan/shinjuku-kawaguchiko/'},
{title:'东京 ⇄ 伊豆',from:'东京站／合适的踊子号停靠站',to:'伊豆高原，转大室山／城崎海岸',line:'踊子号；或经热海→伊东→伊豆急',time:'单程铁路约2–3小时，酒店及景区接驳后约3–4小时',yen:12000,changes:'特急按车次；普通路线需换乘',booking:'特急待预订，基本车票＋特急券；2027列车另核',ic:'不可只凭IC卡乘指定席特急；伊豆急与巴士适用范围另核',url:'https://www.jreast.co.jp/en/multi/traininformation/odoriko/index.html'},
{title:'东京 → 大阪',from:'东京／品川',to:'新大阪→大国町／难波',line:'东海道新干线；对比白天高速巴士与夜巴',time:'新干线约2.5–3小时；门到门约4–5小时；巴士约8–10小时以上',yen:16000,changes:'新大阪转大阪地铁',booking:'全部待预订；1/29夜巴1/30到达，不满足1/29入住，须先改整体安排',ic:'新干线需车票／绑定预约，不能直接刷普通IC通乘',url:'https://smart-ex.jp/en/'},
{title:'大阪 ⇄ 京都',from:'大国町／难波→大阪站',to:'京都站→稻荷；回程河原町／京都',line:'地铁＋JR新快速＋奈良线；东山用京阪／步行，回程可比较阪急',time:'到稻荷约90–120分钟，转场另留',yen:2200,changes:'2次以上，依实际青旅',booking:'普通车通常现场购票，付费特急／指定席另核',ic:'Suica／ICOCA支持区间可用，各运营商票不要混用',url:'https://www.westjr.co.jp/global/sc/'},
{title:'大阪 ⇄ 奈良',from:'近铁大阪难波',to:'近铁奈良',line:'近铁奈良线快速急行；公园内步行',time:'铁路单程约40–60分钟，住宿到站及步行另留',yen:2000,changes:'直达车按班次；普通／快速不保证座位',booking:'普通／快速急行一般现场购票，特急需另购特急券',ic:'支持范围可用，近铁奈良不同于JR奈良',url:'https://www.kintetsu.co.jp/foreign/chinese-han/'},
{title:'难波 → 关西机场',from:'南海难波',to:'关西机场站→实际航站楼',line:'南海机场急行；或Rapi:t指定席',time:'车程约40–55分钟，另留接驳／值机至少3小时',yen:1600,changes:'列车直达，T2还需接驳',booking:'急行一般无需预约；Rapi:t特急券待预订，航班待确认',ic:'普通票支持范围可用；Rapi:t另购特急券',url:'https://www.howto-osaka.com/en/'},
{title:'香港机场 → 深圳 → 长沙',from:'香港国际机场',to:'深圳／深圳北→长沙／长沙南',line:'机场巴士至口岸或机场快线＋港铁东铁至罗湖／落马洲；入境后转深圳地铁／火车',time:'跨境与转站至少预留数小时；普通列车／高铁需按12306实际车次倒推',yen:0,changes:'跨境通关、深圳站点转换，不能视作联程保障',booking:'航班、跨境交通、火车均待预订；优先早抵港，春运查起售／候补；不保证有余票',ic:'日本IC卡不适用；港币交通及国内火车分别支付',url:'https://www.12306.cn/',hkd:200,cny:400}
];
export const networkChecked='2026-11-08';
