import type {Trip} from '@/lib/types';
// User's route, with optional stops kept out of the core timeline to protect rest time.
const rows:[string,string,string,number,string,[string,string][]][]=[
 ['东京','东京','抵达与休息',0,'预留入境、机场到酒店3小时以上；机场接驳在总预算单列，按航班调整。',[]],
 ['东京','东京','浅草、上野与秋叶原',900,'区域间预留30–40分钟；女仆咖啡馆为可选消费，不参加也不影响路线。',[['sensoji','09:00'],['ueno','11:30'],['akihabara','15:00'],['maid-cafe','18:15']]],
 ['东京','东京','神宫、原宿与城市夜景',900,'步行与电车间留30分钟；涩谷SKY可另日替换，避免同日塞满。',[['meiji','09:00'],['harajuku','11:00'],['hachiko','14:00'],['kabukicho','18:00']]],
 ['镰仓','东京','镰仓当天往返',2200,'东京往返镰仓预留各90分钟；江之岛为替换选项，非当天必去。',[['komachi','09:30'],['tsurugaoka','11:00'],['hasedera','13:00'],['kamakura-buddha','14:30'],['kamakura-coast','16:00']]],
 ['河口湖','东京','看天气追富士山',6000,'新宿往返高速巴士预留各2–3小时。大石公园与缆车间预留60分钟；排队或路况不佳则二选一。罗森仅短暂停留，不进入车道拍照。',[['fuji-lawson','10:00'],['kawaguchiko','11:30'],['fuji-ropeway','14:30']]],
 ['京都','京都','东京前往京都、东山',14600,'酒店→车站、乘新干线、寄存行李共预留4–5小时；清水寺若晚到则换日，东山散步为优先。',[['kiyomizu','14:00'],['ninenzaka','16:00']]],
 ['京都','京都','岚山与金阁寺',1600,'岚山→金阁寺约60–90分钟，含午餐与休息。',[['arashiyama','09:00'],['togetsukyo','11:30'],['kinkakuji','14:00']]],
 ['京都','京都','伏见稻荷、二条城与市集',1200,'伏见稻荷至二条城预留60分钟。周一御殿仍需复核临时休止；不登顶也可参拜。',[['fushimi','08:00'],['nijo','11:30'],['nishiki','14:30'],['kawaramachi','17:00']]],
 ['京都','大阪','八坂神社节分待核、移宿大阪',1500,'八坂神社官网常规2月2–3日节分，2027具体场次待公告，不保证参加。看完祇园后取行李，京都→大阪含接驳约90分钟。',[['gion','10:00'],['yasaka','12:00']]],
 ['大阪','大阪','大阪城、梅田与心斋桥',1000,'午后留休息及餐饮；蓝天大厦为可选付费项。',[['osaka-castle','09:30'],['umeda','13:00'],['umeda-sky','16:00'],['shinsaibashi','18:30']]],
 ['奈良','大阪','奈良当天往返',2000,'大阪难波→近铁奈良约40–50分钟，另加酒店接驳。春日大社和奈良町步行较长，可按体力删减。',[['nara-park','09:30'],['todaiji','11:30'],['kasuga','13:30'],['naramachi','15:30']]],
 ['神户','大阪','神户港与城市漫步',1800,'大阪→三宫预留45–60分钟。布引香草园2月5日计划检修关闭，不列为正式游览。',[['kobe-kitano','10:00'],['sannomiya','12:00'],['nankinmachi','13:30'],['kobe-port','16:00'],['harborland','18:00']]],
 ['大阪','大阪','市场、电电城与道顿堀',900,'新世界与通天阁为同区活动，登塔可选；购物设上限，给打包行李留时间。',[['kuromon','09:00'],['den-den','11:00'],['shinsekai','14:00'],['tsutenkaku','16:00'],['dotonbori','18:00']]],
 ['大阪','','关西机场与返程',0,'按实际航班倒推，建议起飞前3小时抵达机场；先办退税出境确认与商品查验，再托运行李，具体顺序遵循机场指示。机场车费在总预算单列。',[]],
];
export function coreTrip(startDate='2027-01-25'):Trip{return {title:'冬日东海道 · 14天13晚',startDate,days:rows.map(([city,stay,title,transit,transportNote,items],i)=>({id:`core-day-${i}`,city,stay:stay?`${stay}经济型住宿（待预订）`:'返程日，无日本住宿',title,transit,intercity:i===5?14000:0,transportNote,items:items.map(([spotId,time],j)=>({id:`core-${i}-${j}`,spotId,time,slot:Number(time.slice(0,2))<12?'morning':Number(time.slice(0,2))<18?'afternoon':'evening'}))}))};}
