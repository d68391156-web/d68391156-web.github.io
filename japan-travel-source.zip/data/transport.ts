export type TransportOption={id:string;route:string;name:string;yen:number;minutes:number;changes:number;reserve:string;ic:string;seat:string;pro:string;con:string;url:string;night?:boolean};
// Planning allowances, not a claim of published or real-time fares. Confirm at the operator.
const rows:[string,string,number,number,number,string,string,string,string,string,string,boolean?][]=[
 ['东京→京都','新干线',14000,160,0,'建议提前约1个月核对发售；Nozomi繁忙期可能全车指定席','普通IC卡不能直接当车票；支持绑定的服务须先订票','指定席／自由席依车次','快、舒适','需到车站接驳','https://smart-ex.jp/en/'],
 ['东京→京都','夜间大巴',6500,480,0,'建议提前预约，价格随日期与座位变动','不可仅刷交通IC卡','预订座位','可能节省一晚酒店','睡眠舒适度低；抵达次日上午应减量','https://willer-travel.com/en/',true],
 ['东京→大阪','新干线',15000,170,0,'建议提前预约','不可仅刷交通IC卡','依车次与票种','耗时短','新大阪到酒店另计','https://smart-ex.jp/en/'],
 ['东京→大阪','夜间大巴',7000,540,0,'建议提前预约','不可仅刷交通IC卡','预订座位','可减少白天转场','冬季延误与疲劳需考虑','https://willer-travel.com/en/',true],
 ['新宿→河口湖','高速大巴',2400,130,0,'建议提前约1个月核对发售、往返都预约','不可仅刷交通IC卡','预订座位','直达且常比特急便宜','堵车延误；不是保时到达','https://highway-buses.jp/'],
 ['新宿→河口湖','富士回游特急',4500,120,0,'建议提前约1个月预约','需基本票＋特急券，非普通IC直接通行','全车指定席，按实际票规','铁路较稳定','班次与指定席有限','https://www.fujikyu-railway.jp/fujikaiyuu/'],
 ['东京→镰仓','JR普通／快速单程',1100,70,0,'普通车通常无需预约','支持范围内可用；勿跨不同IC区域长距离乘车','普通车不指定','从东京站方向直接','往返及江之电需另算','https://www.jreast.co.jp/multi/en/'],
 ['东京→镰仓','小田急江之岛·镰仓周游券（新宿往返）',1700,100,1,'普通车通常无需预约；Romancecar特急另购','周游券与IC选一种，避免重复扣费','普通车不指定','包含规定区间江之电','东京站出发未必合适；比单程时注意口径','https://odakyu-global.com/sc/passes/'],
 ['京都→大阪','JR新快速',600,30,0,'通常无需提前订','可在支持区间使用','普通车不指定；A座席另付','京都站→大阪站快','酒店首末段另计','https://www.westjr.co.jp/global/sc/'],
 ['京都→大阪','阪急京都线',450,45,0,'普通车通常无需提前订','可在支持区间使用','普通车不指定；PRiVACE另付','河原町到梅田方便','京都站不是阪急站','https://www.hankyu.co.jp/global/en/'],
 ['大阪难波→奈良','近铁普通／快速急行',700,45,0,'普通／快速急行通常无需预约','可在支持区间使用','普通车不指定，特急另购券','近铁奈良离公园较近','不要误买特急或混淆JR奈良','https://www.kintetsu.co.jp/foreign/chinese-han/'],
 ['大阪梅田→神户三宫','阪急',350,30,0,'普通车通常无需预约','可在支持区间使用','普通车不指定','市中心连接','各公司梅田站入口不同','https://www.hankyu.co.jp/global/en/'],
 ['大阪梅田→神户三宫','阪神',350,35,0,'普通车通常无需预约','可在支持区间使用','普通车不指定','直达市区','不能拿JR票乘阪神','https://www.hanshin.co.jp/global/en/'],
 ['大阪梅田→神户三宫','JR新快速',500,25,0,'普通车通常无需预约','可在支持区间使用','普通车不指定','速度较快','三之宫站与神户站不同','https://www.westjr.co.jp/global/sc/'],
 ['大阪市区→关西机场','南海机场急行（难波）',1100,50,0,'普通急行通常无需预约','可在支持区间使用','普通车不指定','经济、直达','高峰可能站立','https://www.nankai.co.jp/traffic/'],
 ['大阪市区→关西机场','南海Rapi:t（难波）',1600,40,0,'建议提前订，需特急券','基本票IC可用，特急券另购','指定席','行李空间及座位','比急行贵','https://www.howto-osaka.com/en/'],
 ['大阪市区→关西机场','JR关空快速（大阪站）',1300,70,0,'普通车通常无需预约','可在支持区间使用','普通车不指定','梅田方向方便','注意编组目的地及中途解编提示','https://www.westjr.co.jp/global/sc/'],
];
export const transportOptions:TransportOption[]=rows.map(([route,name,yen,minutes,changes,reserve,ic,seat,pro,con,url,night],i)=>({id:`transport-${i}`,route,name,yen,minutes,changes,reserve,ic,seat,pro,con,url,night}));
export const transportCheckedAt='2026-11-01';
