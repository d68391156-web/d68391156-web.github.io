export const visaFeeSource={
  source:'日本国驻华大使馆 · 赴日签证 Q&A',
  url:'https://www.cn.emb-japan.go.jp/itpr_zh/visa_qa.html',
  effectiveFrom:'2026-07-01',checkedAt:'2026-11-01',currency:'CNY',
  single:715,multiple:1430,
  scope:'中国公民在中国申请赴日签证的一般规费；实际减免及领区请以受理机构为准',
  regionSource:'https://www.cn.emb-japan.go.jp/itpr_ja/consular.html',
};
export type VisaCosts={type:'single'|'multiple';agencyFee:number|null;otherFee:number;agencySource:string};
export const initialVisaCosts:VisaCosts={type:'single',agencyFee:null,otherFee:0,agencySource:''};
export function validVisaCosts(x:unknown):x is VisaCosts{
  if(!x||typeof x!=='object')return false;const v=x as VisaCosts;
  return ['single','multiple'].includes(v.type)&&(v.agencyFee===null||Number.isFinite(v.agencyFee)&&v.agencyFee>=0&&v.agencyFee<=100000)&&Number.isFinite(v.otherFee)&&v.otherFee>=0&&v.otherFee<=100000&&typeof v.agencySource==='string'&&v.agencySource.length<=1000;
}
export function visaCostTotal(v:VisaCosts){return visaFeeSource[v.type]+(v.agencyFee??0)+v.otherFee;}
export function visaNeedsQuote(v:VisaCosts){return v.agencyFee===null||!v.agencySource.trim();}
