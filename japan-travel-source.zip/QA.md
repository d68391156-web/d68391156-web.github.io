# 2026-11-08 photo deduplication and Izu expansion

- All 89 catalog entries have unique local photo paths and unique SHA-256 file contents; all have matching author/license/source records. Original 42 images retained, 47 distinct images added.
- Viewed contact sheets for all newly sourced images; replaced a satellite-view candidate for Lake Ippeki with a photographic view and selected a Komachi shopfront reference.
- Added five optional Izu destinations (seven total); original fixed itinerary preserved.
- pnpm test: 53/53 passed; pnpm typecheck, pnpm build and git diff --check passed.
- Mac Safari local page: observed Izu 7-place filter, all seven destination names, different Mount Omuro and Jogasaki photos, photo attribution links, and preserved styling.
- Not a real mobile-device or 2027 service availability test; seasonal photos are not trip-day forecasts.

# 2026-11-08 itinerary update validation

- Updated existing checkout, with Next.js/React styling and static export retained.
- pnpm test: 51 tests; final results recorded in delivery notes.
- pnpm typecheck and pnpm build executed with the bundled Node runtime.
- Safari on macOS: observed 13-day overview, Tokyo 5 / Osaka 6 hotel nights, all 13 day tabs, core load and weather controls, HND entry and KIX 2027-02-04 departure, and two correct hotel search intervals.
- Map data adds Izu and new requested stops; Google iframe and live directions depend on network. No claim of full mobile-device verification or 2027 service availability.
- Source deployment uses the existing Pages repository, source ZIP fallback extraction, checks and out/ publishing; historical static overlays are not applied.
- Previous QA follows as historical evidence, not current itinerary dates.

# 本次交付验证 · 2026-11-01

## 通过

- 从指定远程完整 clone；检查 main 及全部 8 个 commit 的文件树，读取 Pages 工作流和最近成功发布记录。
- 原始 ZIP（93 文件）和 base64 更新 ZIP（37 文件）完整性通过；56 项图片 / 手册与原包逐字节一致。本机历史构建首页与远程最新更新包首页一致。
- 安装锁定依赖成功。22 项测试通过，涵盖原景点和历史行程、汇率、分享验证、跨日排序、自动排程、可选神户后大阪出境、开放规则、非法日期和天数、报价导入安全验证、隐性费用总成本、预算分类与历史方案撤销。
- TypeScript 独立检查通过；Next.js 16.4.3 production build 成功，静态导出 out/。
- 实际浏览器（最终静态构建）：首页及原景点 / 地图入口显示正常；14 天默认方案；错误天数分配不会覆盖行程；历史 11 天切换与撤销；撤销快照跨刷新保留；上移 / 下移改变顺序并触发时间冲突提示，复原后提示消失。
- 实际浏览器：输入手动测试报价，核对票价＋行李＋国内接驳＋机场费用合计为 3050 元；选择报价后预算更新，刷新后保持。测试样例明确标记为测试、已删除。
- 实际浏览器：导入一条手动 JSON 测试样例成功；费用、币种、来源和查询时间正确显示。测试样例已删除。
- 实际浏览器：预算上限改为 9000 时显示超支；恢复为 10000。预算 JSON 下载成功。
- 390 像素窄屏观察：导航、报价控件、预算卡片可用，document scrollWidth 与 clientWidth 均为 390；已恢复默认视口。
- 截图：交付目录上一级的 `预算页面.png`。截图金额是当时规划预留与有时间戳的汇率计算结果，不是实际价格保证。

## 验证边界

- 本次浏览器使用上下移动和跨刷新验证；鼠标拖拽保留原 dnd-kit 实现，状态移动逻辑有测试，未重新逐个执行所有鼠标拖拽路径。
- 地图组件与 Google / Apple 跳转保留，未承诺国外地图在所有中国网络可访问或实时导航准确。
- 没有真实购买、预订、航班余票、酒店报价或签证资格核验。机票排序由手动报价决定，不是实时全网比价。
- 营业窗口和交通时间为保守规划参数；没有覆盖全部临时休馆、节假日和运营方公告。
- 旧站 Actions 最近成功不等于新版已部署。新版远程分支、PR、CI 和公开部署结果见交付消息，不在此预先声称成功。

## 三平台住宿模块追加验收 · 2026-11-01

- 总计 33 项测试通过（新增 11 项住宿规则测试）；包括跨月 / 跨年 / 闰日、入住退房顺序、人数范围、URL 编码、不编造城市 ID、无效 / 不安全报价、外币换算、个人分摊、不同条件分组、报价替换对应预留、相邻住宿可选、重叠不可重复计费、行程外报价失效、删除后恢复预留。
- 独立 TypeScript 检查和 Next.js production build 成功，未新增第三方依赖。
- 实际浏览器：住宿日期及城市建议可显示，人数设为 0 时平台入口和复制失效；退房等于入住时明确报错并移除查价入口。修复日期输入即时反馈后，在最终构建复验通过。
- 手动录入明确标注为“非真实酒店报价”的验收样例 A，5 晚 1000 CNY，计入预算后住宿金额为 1000 + 8 × 180 = 2440 元。第二条同条件 900 元样例按价格排在前面，但重叠选择被拦截，预算仍为 2440 元。刷新后报价和原选择保持。
- 一键复制条件通过：含城市、入住、退房、夜晚数、成人及房间数。住宿 JSON 下载成功；独立读取文件确认含 2 条测试报价、1 条选择、5 晚覆盖、住宿总额 2440 元。
- 两条测试报价已从浏览器删除，住宿预算恢复 13 × 180 = 2340 元。没有向平台上传报价测试数据。
- 三家网站生成按钮均实际点击并打开新标签页。外部控件读取超时，未确认日期和人数接受；逐平台详细记录见 `docs/HOTEL-LINK-VERIFICATION.md`。
- 手机 390 × 844 视口下查价表单、日期控件和三平台竖排卡片观察通过；页面 scrollWidth 与 clientWidth 均为 390，没有整页横向溢出。已恢复默认视口。

## 飞机票与签证修正追加验证 · 2026-11-01

- 共 42 项测试通过，新增去返程机场和日期、网关切换、日期 / 人数无效值、官方签证费、代办未知状态、预算计费、联网记录归属和日期机场匹配、韩国中转完整航段与搜索条件等验证。
- 类型检查和 Next.js 生产静态构建通过，未增加依赖。
- 实际浏览器识别旧缓存 400 元，显示保留参考但当前签证官方费按 715 元计算；服务费空白时预算显示待核。
- 浏览器选择多次签证并填入明确标记为测试的代办费 200 元，签证部分正确为 1630 元，预算同步增加并显示超支；已恢复单次、服务费未知和空来源，无测试报价遗留。
- 浏览器验证返程早于去程时禁用按日期查询；恢复后显示正确的 CSX → TYO 和 KIX → CSX 链接。韩国方案仍查完整航段，明确要求平台手动筛选中转点。
- 浏览器展开联网记录：13 条指示价、来源、原始日期与北京时间获取时间显示正常；默认去返程均为 0 条匹配，不假装当日无航班或报出虚构往返合计。
- 最终构建复验：预算导出包含 `budget.visa=715`、`visaDetails.agencyFee=null`、`visaFeePending=true`、`legacyVisaTotal=400`、官方来源和签证分项 715 元，已独立读取下载文件确认。
- 新增区域在 390 × 844 手机视口下观察通过，页面宽度与视口宽度均为 390；已恢复默认尺寸。
- 截图保存为交付目录中的 `机票联网查价页面.png` 与 `签证费用核验页面.png`。数据核验使用 Skyscanner 月份指示价与使馆公开页面；没有精确日期的实时查询结果，不以缓存价格充当实时结果。

## 2026-11-01 14天核心方案增量验收

- 自动测试50项：原汇率、行程、机票、酒店回归；新增固定日期和5/3/5住宿、近郊不住宿、74地点唯一性、税额和门槛、夜巴取消条件、支出JSON及汇率快照、城际拆分防重复计费。核心路线无机器检测到的时间／闭馆冲突，不等于实路交通及2027营业日历均已确认。
- 独立TypeScript检查、Next生产静态构建通过；未增加依赖。
- 本机生产成品浏览器：载入核心方案显示01-25至02-07、14天13晚、东京5／京都3／大阪5；旧本地方案可切回。8%含税5400拆税前5000税额400正确。
- 手机390×844：交通、退税、预算页document宽度与scrollWidth均390，无页面横向溢出；交通路线可切换。视口已复原。
- 实际支出录入1000JPY、快照0.05：实际50CNY、余9950，刷新仍保留；已删除测试记录，恢复0支出。未操作真实预订或付款。
- 未逐项核实新增地点的2027营业日历、全部实时票价、外国学生ISIC认可；原图片保留，新增城市示意图不宣称实景。
- GitHub集成再次创建分支返回403 Resource not accessible by integration；未获得写入，不能认定远端已更新或部署成功。
