"use client";
import { BookingInfo } from "./BookingInfo";
import { MapLinks } from "./MapLinks";
import { Money } from "./CurrencyProvider";
import Image from "next/image";
import { Clock3, MapPin, Plus, Ticket, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Spot } from "@/lib/types";
export function SpotCard({spot,active,onSelect,onHover,onAdd}:{spot:Spot;active:boolean;onSelect:()=>void;onHover:(id:string|null)=>void;onAdd:()=>void}) {
 const variable=["suntory","hakone-onsen","jozankei"].includes(spot.id);
 return <article className={`spot-card ${active?"is-active":""}`} onMouseEnter={()=>onHover(spot.id)} onMouseLeave={()=>onHover(null)}>
   <button className="spot-photo" onClick={onSelect} aria-label={`在地图中查看${spot.name}`}>
     <Image src={spot.image} style={{objectPosition:spot.photo?.position || 'center'}} alt={spot.imageIllustration?`${spot.city}城市示意图，非该地点实景`:spot.photo?.alt || `${spot.name}照片`} fill sizes="(max-width: 640px) 90vw, 360px" />
     <span className="photo-caption">{spot.imageIllustration?'城市示意图，非该地点实景':spot.photo?.caption || spot.name}</span><span className="photo-price">{spot.priceKnown===false?"待核价":spot.price?<Money yen={spot.price}/>:variable?"消费另计":"免门票"}</span>
   </button>
   <div className="spot-info"><div className="spot-heading"><button onClick={onSelect}><h3>{spot.name}</h3></button><a href={spot.source} target="_blank" rel="noreferrer" aria-label={`${spot.name}官方资料`}><ArrowUpRight size={16}/></a></div>
     <p className="spot-ja">{spot.ja} <span>/ {spot.en}</span></p>
     <div className="spot-tags">{spot.tags.slice(0,2).map(t=><Badge key={t} variant="secondary">{t}</Badge>)}</div>
     <p className="spot-line"><Clock3 size={13}/><span>{spot.hours}</span></p>
     <p className="spot-line"><MapPin size={13}/><span>{spot.station}</span></p>
     <p className="spot-tip">{spot.tips}</p>
     <div className="spot-facts"><p><Ticket size={13}/><b>门票参考</b><span>{spot.priceKnown===false?"门票／消费待核实":spot.price?<><Money yen={spot.price}/> / 成人</>:variable?"消费另计":<><Money yen={0}/> · 普通区域免费</>}</span></p><p><Clock3 size={13}/><b>参观建议用时</b><span>{spot.duration} 分钟</span></p></div><p className="price-note">{spot.priceNote}</p><BookingInfo spot={spot}/><details><summary>景点详情与学生优惠</summary><p>{spot.ja} · {spot.city} · 地图参考坐标 {spot.lat}, {spot.lng}</p><p>推荐时段：{spot.recommendedTime||"按开放时间安排；冬季户外尽量16:30前完成"}</p><p>{spot.studentPolicy||"学生票资格及所需证明待场馆确认；不计入承诺优惠。"}</p><p>最后核实：{spot.checkedAt}。临时休馆及2027开放日历请查官网。</p><a href={spot.source} target="_blank" rel="noreferrer">查看官方资料</a></details><div className="spot-bottom"><Button size="sm" onClick={onAdd} aria-label={`添加${spot.name}到行程`}><Plus size={14}/>加入行程</Button></div>
     <div className="photo-meta">{spot.photo&&<a href={`/images/credits.html#${spot.id}`} target="_blank" rel="noreferrer" title={`${spot.photo.author} · ${spot.photo.license}`} aria-label={`${spot.name}照片作者与授权来源`}>照片来源 · {spot.photo.license}</a>}<MapLinks spot={spot}/></div>
   </div>
 </article>;
}
