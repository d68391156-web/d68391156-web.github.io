import { ArrowUpRight } from 'lucide-react';
import { mapLink } from '@/lib/maps';
import type { Spot } from '@/lib/types';
export function MapLinks({spot,origin,walking=false}:{spot:Spot;origin?:Spot;walking?:boolean}){
 return <span className="map-links">{(['google','apple'] as const).map(provider=><a key={provider} href={mapLink(provider,spot,origin,walking)} target="_blank" rel="noreferrer" aria-label={`${provider==='google'?'Google':'苹果'}地图${origin?'导航到':'查看'}${spot.name}`}>{provider==='google'?'Google 地图':'苹果地图'}<ArrowUpRight size={11}/></a>)}</span>;
}
