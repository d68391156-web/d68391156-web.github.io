"use client";
import { Check, ExternalLink, CalendarCheck, Smartphone, CreditCard, Wifi, ShoppingBag, QrCode } from "lucide-react";
import { useTripStore } from "@/lib/store";
import { bookings } from "@/lib/catalog";
import { JrCalculator } from "./JrCalculator";
const essentials=[
 {id:'ic',icon:Smartphone,title:'准备交通 IC 卡',text:'确认手机支持 Suica / ICOCA，或落地购买适用实体卡。不同卡的发行、使用期限和充值方式分别确认。',url:'https://www.jreast.co.jp/multi/en/welcomesuica/welcomesuica.html'},
 {id:'vjw',icon:QrCode,title:'Visit Japan Web 与入境二维码',text:'通过日本数字厅官方免费服务填写入境和海关申报；不是签证申请，不要把二维码交给付费代办网站。',url:'https://services.digital.go.jp/en/visit-japan-web/'},
 {id:'internet',icon:Wifi,title:'eSIM / Pocket Wi-Fi',text:'检查手机是否解锁及支持 eSIM；按旅游天数、流量、热点和取还设备条件选择。'},
 {id:'balance',icon:CreditCard,title:'IC 卡余额与支付备选',text:'出站需足够余额。准备银行卡和少量现金；IC 卡不代替特急指定席车票。'},
 {id:'tax',icon:ShoppingBag,title:'2027 年旅行：核对新的退税流程',text:'按日本海关公告，2026 年 11 月 1 日起购物改为离境确认后退税。购物时确认店铺退款方式、商品与凭证要求，离境前预留办理时间。',url:'https://www.customs.go.jp/kaigairyoko/taxrefund_e.html'},
 {id:'docs',icon:Check,title:'护照、签证、保险与订单备份',text:'按本人护照和签证类别确认入境条件；保存住宿、机票和保险资料，现场可能需要出示。'},
];
export function Toolkit(){const {checks,toggleCheck}=useTripStore();return <div className="toolkit-grid"><JrCalculator/><section className="tool-card"><div className="tool-heading"><CalendarCheck size={21}/><div><h2>出发前，逐项打勾。</h2><p>状态保存在当前浏览器，不会替你完成预订。</p></div></div><div className="essentials">{essentials.map(e=>{const Icon=e.icon;return <label className={`essential ${checks[e.id]?'checked':''}`} key={e.id}><input type="checkbox" checked={!!checks[e.id]} onChange={()=>toggleCheck(e.id)}/><Icon size={18}/><span><strong>{e.title}</strong><p>{e.text}</p>{e.url&&<a href={e.url} target="_blank" rel="noreferrer" onClick={event=>event.stopPropagation()}>官方说明 <ExternalLink size={11}/></a>}</span></label>;})}</div></section>
 <section className="tool-card booking-card"><div className="tool-heading"><CalendarCheck size={21}/><div><h2>原行程预约日历</h2><p>基于 2027/1/23 出发的固定计划；修改行程后请重新核对。预约时刻均为香港 / 北京时间。</p></div><a href="/handbook/booking-calendar.ics" download className="text-link">下载 .ics 日历</a></div><div className="booking-grid">{bookings.map(b=><label key={b.id} className={`booking-row ${checks['book-'+b.id]?'checked':''}`}><input type="checkbox" checked={!!checks['book-'+b.id]} onChange={()=>toggleCheck('book-'+b.id)}/><span><small>{b.time}</small><strong>{b.title}</strong><p>{b.detail}</p>{'url' in b&&<a href={b.url} target="_blank" rel="noreferrer" onClick={e=>e.stopPropagation()}>查看官方信息</a>}</span></label>)}</div></section>
 </div>;}
