'use client';
import {visaFeeSource,visaCostTotal,visaNeedsQuote,type VisaCosts} from '@/data/visa-fees';
export function VisaFees({value,onChange,legacyTotal}:{value:VisaCosts;onChange:(v:VisaCosts)=>void;legacyTotal:number|null}){
 const fee=visaFeeSource[value.type];
 return <section className="planning-panel" aria-label="签证费用与联网核验"><span className="eyebrow">签证费用 · 官方规费与代办分开</span><h2>先核对官方标准，再询价代办。</h2><p>中国公民一般赴日签证规费：单次 715 元、多次 1430 元，自 {visaFeeSource.effectiveFrom} 起实施。代办服务费另计，不应把 400 元视为签证及代办的官方合计。</p>
 <p><a href={visaFeeSource.url} target="_blank" rel="noopener noreferrer">{visaFeeSource.source} ↗</a> · 资料核对 {visaFeeSource.checkedAt}。这是本次联网核验记录，不是网页自动持续更新；正式申请前再次打开官方来源核实。</p>
 <p>湖南列于驻华大使馆管辖地区；实际送签以居住地及指定机构要求为准。<a href={visaFeeSource.regionSource} target="_blank" rel="noopener noreferrer">官方领区说明 ↗</a></p>
 {legacyTotal!==null&&<p className="inline-notice">旧版签证合计 {legacyTotal} 元已保留作参考，未删除；当前按官方规费＋下面的服务费重新计算。旧版总价低于规费时不可直接当作可办理报价。</p>}
 <div className="planning-fields"><label>签证类别<select aria-label="签证类别" value={value.type} onChange={e=>onChange({...value,type:e.target.value as VisaCosts['type']})}><option value="single">单次</option><option value="multiple">多次</option></select></label><label>官方签证费（人民币）<input aria-label="官方签证费" readOnly value={fee}/></label><label>代办服务费（人民币，未知请留空）<input aria-label="签证代办服务费" type="number" min="0" max="100000" step="0.01" value={value.agencyFee??''} placeholder="待核实，不等于免费" onChange={e=>onChange({...value,agencyFee:e.target.value===''?null:Number(e.target.value)})}/></label><label>快递 / 照片等其他费用<input aria-label="签证其他费用" type="number" min="0" max="100000" step="0.01" value={value.otherFee} onChange={e=>onChange({...value,otherFee:Number(e.target.value)})}/></label><label>代办报价来源与查询日期<input aria-label="签证代办报价来源" maxLength={1000} value={value.agencySource} placeholder="例如：旅行社名称、2026-11-01；预留则写明预留" onChange={e=>onChange({...value,agencySource:e.target.value})}/></label></div>
 <p role="status">当前计入签证部分 ¥{visaCostTotal(value).toFixed(2)}。{value.agencyFee===null?'代办服务费尚未核价，此金额不是最终签证总成本。':visaNeedsQuote(value)?'代办金额尚无来源，按手动预留处理；请补充来源。':'服务费按你录入的报价 / 预留与来源计算，请与代办确认。'}</p>
 <a href="https://www.google.com/search?q=site%3Acn.emb-japan.go.jp+%E7%AD%BE%E8%AF%81+%E6%89%8B%E7%BB%AD%E8%B4%B9" target="_blank" rel="noopener noreferrer">联网搜索使馆最新费用通知 ↗</a></section>;
}
