"use client";
import { Money } from "./CurrencyProvider";
import { useState } from "react";
import { Plus, Trash2, TrainFront, ArrowRight } from "lucide-react";
import { jrComparison,railRoutes } from "@/lib/travel";
import { Button } from "./ui/button";
export function JrCalculator(){
 const [days,setDays]=useState<7|14>(7),[channel,setChannel]=useState<"official"|"agency">('official');const [routes,setRoutes]=useState([{routeId:'odawara-kyoto',count:1},{routeId:'kyoto-osaka',count:1}]);const [next,setNext]=useState('osaka-hiroshima');const result=jrComparison(routes,days,channel);
 return <section className="tool-card jr-tool"><div className="tool-heading"><TrainFront size={21}/><div><h2>JR Pass 值不值得买？</h2><p>按同一有效期内的成人普通车参考车费比较。</p></div></div>
 <div className="tool-fields"><label>有效期<select value={days} onChange={e=>setDays(Number(e.target.value) as 7|14)}><option value={7}>连续 7 天</option><option value={14}>连续 14 天</option></select></label><label>购买渠道<select value={channel} onChange={e=>setChannel(e.target.value as 'official'|'agency')}><option value="official">官方在线（暂维持原价）</option><option value="agency">海外代理（2026/10 起）</option></select></label></div>
 <div className="jr-legs">{routes.map((r,i)=>{const q=railRoutes.find(x=>x.id===r.routeId)!;return <div key={i} className="jr-leg"><div><strong>{q.from} <ArrowRight size={12}/> {q.to}</strong><small>{q.note}{!q.jrEligible?' · 不纳入 JR 省钱额':''}</small></div><label><span className="sr-only">{q.from}到{q.to}次数</span><input type="number" min={1} max={20} value={r.count} onChange={e=>{const count=Math.max(1,Math.min(20,Number(e.target.value)||1));setRoutes(routes.map((v,j)=>i===j?{...v,count}:v));}}/>次</label><b><Money yen={q.cost*r.count}/></b><button className="icon-button" onClick={()=>setRoutes(routes.filter((_,j)=>i!==j))} aria-label={`移除${q.from}到${q.to}`}><Trash2 size={15}/></button></div>;})}</div>
 <div className="add-leg"><select aria-label="新增城际路线" value={next} onChange={e=>setNext(e.target.value)}>{railRoutes.map(r=><option key={r.id} value={r.id}>{r.from} → {r.to}</option>)}</select><Button variant="outline" onClick={()=>setRoutes([...routes,{routeId:next,count:1}])} disabled={routes.length>=20}><Plus size={14}/>添加路段</Button></div>
 <div className={`jr-result ${result.saving>0?'worth':''}`} aria-live="polite"><div><span>{result.saving>0?'理论上可节省':'单买更划算'}</span><strong><Money yen={Math.abs(result.saving)}/></strong></div><p>JR 可覆盖单买车费 <Money yen={result.eligible}/><br/>通票 <Money yen={result.pass}/>；含非 JR 路段合计 <Money yen={result.withPass}/></p></div>
 <p className="tool-footnote">手动确保所选路段落在连续 {days} 天内。默认比较可覆盖的 Hikari / Sakura 等服务；Nozomi / Mizuho 通票附加票未计入。这里不是实时查价，也不保证票种资格。<a href="https://japanrailpass.net/assets/pdf/JRP_Price_Changes_En.pdf" target="_blank" rel="noreferrer">官方价格说明</a></p>
 </section>;
}
