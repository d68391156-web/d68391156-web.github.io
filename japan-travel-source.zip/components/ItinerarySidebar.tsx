"use client";
import { BookingInfo } from "./BookingInfo";
import { MapLinks } from "./MapLinks";
import { Money } from "./CurrencyProvider";
import { useState } from "react";
import { DndContext, DragOverlay, PointerSensor, KeyboardSensor, useSensor, useSensors, useDroppable, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, useSortable, verticalListSortingStrategy, sortableKeyboardCoordinates } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Trash2, Plus, ArrowUp, ArrowDown, AlertTriangle, TrainFront, MapPin, Sunrise, Sun, Moon } from "lucide-react";
import { useTripStore } from "@/lib/store";
import { spotById } from "@/lib/catalog";
import { scheduleWarnings, localMinutes } from "@/lib/planning";
import { dayCosts, distanceKm, tripDate, transferEstimate } from "@/lib/travel";
import { SLOTS, SLOT_NAMES, type DayPlan, type ItineraryItem, type Slot } from "@/lib/types";
import { Button } from "./ui/button";
const SlotIcon={morning:Sunrise,afternoon:Sun,evening:Moon};
function DayTarget({day,index,active,onClick}:{day:DayPlan;index:number;active:boolean;onClick:()=>void}) {
 const {setNodeRef,isOver}=useDroppable({id:`day:${day.id}`,data:{dayId:day.id}});
 return <button ref={setNodeRef} onClick={onClick} className={`day-chip ${active?'active':''} ${isOver?'drag-over':''}`} aria-pressed={active}><span>第 {index+1} 天</span><strong>{day.title}</strong><small>{day.items.length} 个地点</small></button>;
}
function SortableItem({item,day,onSelect}:{item:ItineraryItem;day:DayPlan;onSelect:(id:string)=>void}) {
 const {attributes,listeners,setNodeRef,setActivatorNodeRef,transform,transition,isDragging}=useSortable({id:item.id,data:{dayId:day.id,slot:item.slot}});
 const {trip,checks,toggleCheck,removeItem,moveItem,setTime}=useTripStore();const spot=spotById.get(item.spotId);if(!spot)return null;
 const position=day.items.findIndex(x=>x.id===item.id),previous=position>0?spotById.get(day.items[position-1].spotId):undefined;
 const siblings=day.items.filter(x=>x.slot===item.slot),idx=siblings.findIndex(x=>x.id===item.id);
 const move=(delta:number)=>{if(delta<0&&idx>0)moveItem(item.id,day.id,item.slot,siblings[idx-1].id);if(delta>0&&idx<siblings.length-1)moveItem(item.id,day.id,item.slot,siblings[idx+2]?.id);};
 return <div ref={setNodeRef} style={{transform:CSS.Transform.toString(transform),transition,opacity:isDragging?.35:1}} className="itinerary-item">
 <button ref={setActivatorNodeRef} {...attributes} {...listeners} className="drag-handle" aria-label={`拖动${spot.name}，空格拾起，方向键移动，空格放下`}><GripVertical size={16}/></button>
 <div className="item-main"><div className="item-title"><button onClick={()=>onSelect(spot.id)}>{spot.name}</button><button className="icon-button" onClick={()=>removeItem(day.id,item.id)} aria-label={`移除${spot.name}`}><Trash2 size={14}/></button></div>
 <p><MapPin size={11}/>{spot.station}</p><div className="item-settings"><input type="time" value={item.time} aria-label={`${spot.name}时间`} onChange={e=>setTime(day.id,item.id,e.target.value)}/><span>门票 {spot.priceKnown===false?"待核价":<Money yen={spot.price}/>}</span><div className="move-arrows"><button aria-label={`上移${spot.name}`} disabled={idx===0} onClick={()=>move(-1)}><ArrowUp size={12}/></button><button aria-label={`下移${spot.name}`} disabled={idx===siblings.length-1} onClick={()=>move(1)}><ArrowDown size={12}/></button></div></div>
 <div className="move-selects"><select aria-label={`移动${spot.name}到日期`} value={day.id} onChange={e=>moveItem(item.id,e.target.value,item.slot)}>{trip.days.map((d,i)=><option key={d.id} value={d.id}>第 {i+1} 天 · {d.title}</option>)}</select><select value={item.slot} aria-label={`${spot.name}时段`} onChange={e=>moveItem(item.id,day.id,e.target.value as Slot)}>{SLOTS.map(s=><option key={s} value={s}>{SLOT_NAMES[s]}</option>)}</select></div>
 <p>参观建议用时：{spot.duration} 分钟 · {spot.hours}</p>{previous&&<p className="item-transfer">从{previous.name}出发：{distanceKm(previous,spot)<1.2?"步行":"公共交通＋步行"}，约 {localMinutes(previous,spot)} 分钟；段交通粗估 <Money yen={transferEstimate(previous,spot)}/>（供核对，全程按全天交通预算计费）</p>}<div className="planning-actions">{["已游览","已预约","待确认"].map(status=><label key={status}><input type="checkbox" checked={!!checks[item.id+status]} onChange={()=>toggleCheck(item.id+status)}/>{status}</label>)}</div><BookingInfo spot={spot} compact/><MapLinks spot={spot}/>
 </div></div>;
}
function SlotDrop({day,slot,onSelect}:{day:DayPlan;slot:Slot;onSelect:(id:string)=>void}) {
 const {setNodeRef,isOver}=useDroppable({id:`slot:${day.id}:${slot}`,data:{dayId:day.id,slot}});const items=day.items.filter(x=>x.slot===slot),Icon=SlotIcon[slot];
 return <section className={`slot-group ${isOver?'drag-over':''}`} ref={setNodeRef}><h4><Icon size={16}/>{SLOT_NAMES[slot]}<span>{items.length} 站</span></h4><SortableContext items={items.map(i=>i.id)} strategy={verticalListSortingStrategy}>{items.map(i=><SortableItem key={i.id} item={i} day={day} onSelect={onSelect}/>)}</SortableContext>{!items.length&&<p className="empty-slot">把地点拖到这里，或从探索页加入</p>}</section>;
}
export function ItinerarySidebar({onSelect,compact=false}:{onSelect:(id:string)=>void;compact?:boolean}) {
 const {trip,activeDay,setActiveDay,moveItem,setTransit,addDay}=useTripStore();const [dragId,setDragId]=useState<string|null>(null);const [notice,setNotice]=useState("");
 const sensors=useSensors(useSensor(PointerSensor,{activationConstraint:{distance:7}}),useSensor(KeyboardSensor,{coordinateGetter:sortableKeyboardCoordinates}));
 const day=trip.days.find(x=>x.id===activeDay)||trip.days[0],index=trip.days.indexOf(day),cost=dayCosts(day);
 const active=trip.days.flatMap(d=>d.items).find(i=>i.id===dragId);
 const warnings=day.items.slice(1).map((item,i)=>{const a=spotById.get(day.items[i].spotId)!,b=spotById.get(item.spotId)!;return {a,b,km:distanceKm(a,b)};}).filter(x=>x.km>30);
 const timeWarnings=SLOTS.flatMap(slot=>{const items=day.items.filter(x=>x.slot===slot);return items.slice(1).filter((x,i)=>x.time<items[i].time);});
 function drop(e:DragEndEvent){setDragId(null);if(!e.over||e.active.id===e.over.id)return;const target=e.over.data.current;let dayId=target?.dayId as string|undefined;let slot=target?.slot as Slot|undefined;const current=trip.days.flatMap(d=>d.items).find(i=>i.id===e.active.id);if(!current||!dayId)return;slot=slot||current.slot;const before=String(e.over.id).startsWith('slot:')||String(e.over.id).startsWith('day:')?undefined:String(e.over.id);moveItem(String(e.active.id),dayId,slot,before);setActiveDay(dayId);setNotice('已移动地点，预算已重新计算。');}
 const total=trip.days.reduce((n,d)=>n+dayCosts(d).total,0);
 return <div className={`itinerary-builder ${compact?'compact':''}`}><div className="builder-top"><div><h2>把喜欢的地方，排进每一天。</h2><p>拖动把手调整顺序，也可用日期和时段下拉框移动。</p></div><Button variant="outline" size="sm" onClick={addDay} disabled={trip.days.length>=31}><Plus size={14}/>增加一天</Button></div>
 <DndContext sensors={sensors} onDragStart={e=>setDragId(String(e.active.id))} onDragCancel={()=>setDragId(null)} onDragEnd={drop}>
 <div className="day-tabs">{trip.days.map((d,i)=><DayTarget key={d.id} day={d} index={i} active={day.id===d.id} onClick={()=>setActiveDay(d.id)}/>)}</div>
 <div className="builder-columns"><div><div className="active-day-heading"><div><small>{tripDate(trip.startDate,index)} · 第 {index+1} 天</small><h3>{day.title}</h3><p>住宿：{day.stay}</p><label>编辑标题<input aria-label="当天行程标题" value={day.title} onChange={e=>useTripStore.getState().setDayInfo(day.id,e.target.value,day.stay)}/></label><label>编辑住宿<input aria-label="当天住宿城市说明" value={day.stay} onChange={e=>useTripStore.getState().setDayInfo(day.id,day.title,e.target.value)}/></label></div><span>{day.items.length} 个地点</span></div>
 {SLOTS.map(s=><SlotDrop key={s} day={day} slot={s} onSelect={onSelect}/>)}
 {!!warnings.length&&<div className="distance-warnings" role="status">{warnings.map((w,i)=><p key={i}><AlertTriangle size={15}/><span>{w.a.name} → {w.b.name} 直线约 {Math.round(w.km)} 公里，{w.km>100?'需安排城际交通或跨区域转场。':'请预留乘车时间，勿按步行衔接。'}</span></p>)}</div>}
 {scheduleWarnings(trip,index).map((w,i)=><p className="inline-notice" key={i}>{w}</p>)}
 {!!timeWarnings.length&&<p className="inline-notice">部分时间早于上一站，请在拖拽后手动调整时刻。</p>}
 </div><aside className="day-budget"><span className="eyebrow">第 {index+1} 天参考费用</span><strong><Money yen={cost.total}/></strong><p>按上方联网汇率换算；原始预算以日元保存。</p><div className="budget-line"><span>门票</span><b><Money yen={cost.tickets}/></b></div><div className="budget-line"><span>交通{day.transit<0?' · 自动':' · 全天预算'}</span><b><Money yen={cost.transit}/></b></div>
 <label className="check-line"><input type="checkbox" checked={day.transit<0} onChange={e=>setTransit(day.id,e.target.checked?-1:cost.autoTransit)}/>自动估算相邻地点交通</label>
 {day.transit>=0&&<label className="field-label">全天交通预算（日元，含下方城际部分）<input type="number" min="0" max="1000000" value={day.transit} onChange={e=>setTransit(day.id,Number(e.target.value))}/></label>}
 <label className="field-label">其中新干线／夜巴（日元）<input type="number" min="0" max={Math.max(0,cost.transit)} value={day.intercity||0} onChange={e=>useTripStore.getState().setIntercity(day.id,Math.min(cost.transit,Math.max(0,Number(e.target.value)||0)))}/></label><small>{day.transit<0?'按相邻地点直线距离粗估；不含酒店首末段、机场接驳和特殊附加费。跨城请核对后改用全天预算。':'此项已包含当天车费预算，不再叠加自动估算。拖拽跨天后请核对交通预算。'}</small><hr/><div className="budget-line"><span>全程门票＋交通</span><b><Money yen={total}/></b></div><small>人民币换算使用上方注明时间与来源的汇率。不含机票、住宿、餐饮。</small>
 </aside></div>
 <DragOverlay>{active&&<div className="drag-preview"><GripVertical size={16}/>{spotById.get(active.spotId)?.name}</div>}</DragOverlay>
 </DndContext><p className="sr-only" aria-live="polite">{notice}</p>
 <details className="transport-details"><summary><TrainFront size={16}/>当天原计划的交通与换乘</summary><p>这是原行程参考说明；修改景点后不会自动变成新的实时换乘方案。</p><ol>{day.transportNote.split('\n').filter(Boolean).map((t,i)=><li key={i}>{t}</li>)}</ol>{!day.transportNote&&<p>请按最终地点打开地图查询交通。</p>}</details>
 </div>;
}
