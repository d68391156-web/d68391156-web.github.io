'use client';
import {createContext,useCallback,useContext,useEffect,useRef,useState,type ReactNode} from 'react';
import {moneyText,parseQuote,validQuote,type CurrencyMode,type ExchangeQuote} from '@/lib/currency';
type CurrencyState={mode:CurrencyMode;setMode:(mode:CurrencyMode)=>void;quote:ExchangeQuote|null;loading:boolean;error:string;cached:boolean;refresh:()=>Promise<void>};
const Context=createContext<CurrencyState|null>(null);
export function CurrencyProvider({children}:{children:ReactNode}){
 const [mode,setModeState]=useState<CurrencyMode>('both'),[quote,setQuote]=useState<ExchangeQuote|null>(null),[loading,setLoading]=useState(false),[error,setError]=useState(''),[cached,setCached]=useState(false);
 const busy=useRef(false),lastTry=useRef(0),alive=useRef(true),controller=useRef<AbortController|null>(null);
 const refresh=useCallback(async()=>{
  if(busy.current||Date.now()-lastTry.current<10000)return;busy.current=true;lastTry.current=Date.now();setLoading(true);setError('');let received=false;
  for(const [source,url] of [['exchangerate.dev','https://api.exchangerate.dev/v1/rate/jpy-cny'],['Frankfurter','https://api.frankfurter.dev/v2/rate/JPY/CNY']] as const){
   const abort=new AbortController();controller.current=abort;const timeout=setTimeout(()=>abort.abort(),8000);
   try{const res=await fetch(url,{signal:abort.signal,cache:'no-store',credentials:'omit'});if(!res.ok)throw Error();const q=parseQuote(await res.json(),source);if(!alive.current)break;setQuote(q);setCached(false);try{localStorage.setItem('japan-fx-quote-v1',JSON.stringify(q));}catch{}received=true;break;}catch{}finally{clearTimeout(timeout);}
  }
  if(alive.current){if(!received){setCached(true);setError('联网更新失败；有缓存时显示上次报价。');}setLoading(false);}busy.current=false;
 },[]);
 useEffect(()=>{alive.current=true;try{const saved=localStorage.getItem('japan-currency-mode');if(saved==='both'||saved==='JPY'||saved==='CNY')setModeState(saved);const stored=JSON.parse(localStorage.getItem('japan-fx-quote-v1')||'null');if(validQuote(stored)){setQuote(stored);setCached(true);}}catch{}void refresh();const tick=()=>{if(document.visibilityState==='visible'&&Date.now()-lastTry.current>=300000)void refresh();};const online=()=>void refresh();const timer=setInterval(tick,300000);window.addEventListener('focus',tick);window.addEventListener('online',online);return()=>{alive.current=false;controller.current?.abort();clearInterval(timer);window.removeEventListener('focus',tick);window.removeEventListener('online',online);};},[refresh]);
 function setMode(next:CurrencyMode){setModeState(next);try{localStorage.setItem('japan-currency-mode',next);}catch{}}
 return <Context.Provider value={{mode,setMode,quote,loading,error,cached,refresh}}>{children}</Context.Provider>;
}
export function useCurrency(){const value=useContext(Context);if(!value)throw Error('CurrencyProvider missing');return value;}
export function Money({yen}:{yen:number}){const {mode,quote}=useCurrency();return <span className="money-value">{moneyText(yen,mode,quote)}</span>;}
export function CurrencyBar(){
 const {mode,setMode,quote,loading,error,cached,refresh}=useCurrency();const [,setMinute]=useState(0);useEffect(()=>{const id=setInterval(()=>setMinute(x=>x+1),60000);return()=>clearInterval(id);},[]);
 const old=!!quote&&(quote.stale||Date.now()-Date.parse(quote.fetchedAt)>20*60000||quote.kind==='intraday'&&quote.market==='open'&&Date.now()-Date.parse(quote.observedAt)>45*60000);
 const date=(iso:string)=>new Date(iso).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
 return <section className="currency-bar" aria-label="货币与联网汇率"><div className="currency-controls"><strong>费用显示</strong><div role="group" aria-label="选择费用币种">{(['both','JPY','CNY'] as const).map(m=><button key={m} aria-pressed={mode===m} onClick={()=>setMode(m)}>{m==='both'?'日元＋人民币':m==='JPY'?'日元 JPY':'人民币 CNY'}</button>)}</div><button className="currency-refresh" onClick={()=>void refresh()} disabled={loading}>{loading?'获取中…':'刷新汇率'}</button></div><div className="currency-rate" role="status">{quote?<><b>100 日元 ≈ {(quote.rate*100).toFixed(4)} 人民币</b><span>{cached?'缓存报价':old?'报价较旧':quote.kind==='daily'?'每日参考汇率':'联网日内报价 · 约延迟 15 分钟'} · {quote.kind==='daily'?`数据日期 ${quote.observedAt.slice(0,10)}`:`报价 ${date(quote.observedAt)}`}{quote.market==='weekend'?' · 周末休市':quote.market==='interbank_closed'?' · 市场休市':''}</span><span>最近获取 {date(quote.fetchedAt)}（北京时间） · <a href={quote.source==='Frankfurter'?'https://frankfurter.dev/':'https://exchangerate.dev/'} target="_blank" rel="noreferrer">汇率来源：{quote.source}</a></span></>:<span>{loading?'正在联网获取最新日元兑人民币报价…':'暂无汇率，保留日元原价，暂不估算人民币。'}</span>}{error&&<span className="currency-error">{error}</span>}<small>每 5 分钟尝试更新；日内源不可用时使用有日期的每日参考价。金额仅用于旅游预算，实际换汇及刷卡含银行汇差和手续费。</small></div></section>;
}
