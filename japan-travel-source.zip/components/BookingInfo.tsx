import type { Spot } from '@/lib/types';
export function BookingInfo({spot,compact=false}:{spot:Spot;compact?:boolean}){
 const b=spot.booking;if(!b)return null;
 return <details className={`spot-booking ${compact?'compact-booking':''}`}><summary>门票与预约 · {b.status}</summary><div><p><b>提前多久：</b>{b.advance}</p><p><b>在哪办理：</b>{b.where}</p>{b.note&&<p>{b.note}</p>}<a href={b.url} target="_blank" rel="noreferrer">官方购票／预约说明 ↗</a><small>此处官方原价中的 ¥ 均指日元；上方门票支持人民币换算。核对于 {b.checkedAt}；实际票价、放票与开放日期以官方为准。</small></div></details>;
}
