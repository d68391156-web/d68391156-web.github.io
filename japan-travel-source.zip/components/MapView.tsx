"use client";
import { Money } from "./CurrencyProvider";
import { MapLinks } from "./MapLinks";
import { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, GeoJSON, useMap } from "react-leaflet";
import L from "leaflet";
import type { Spot } from "@/lib/types";
import { distanceKm } from "@/lib/travel";
import { MapPin, Route, ExternalLink } from "lucide-react";
import geography from "@/data/japan-boundaries.json";
import type { GeoJsonObject } from "geojson";
function Camera({spots,selected}:{spots:Spot[];selected:string|null}) {
 const map=useMap();
 useEffect(()=>{if(spots.length){map.fitBounds(L.latLngBounds(spots.map(s=>[s.lat,s.lng])),{padding:[45,45],maxZoom:12,animate:false});}map.invalidateSize();},[spots,map]);
 useEffect(()=>{const p=spots.find(s=>s.id===selected);if(p)map.flyTo([p.lat,p.lng],Math.max(map.getZoom(),12),{animate:!window.matchMedia('(prefers-reduced-motion: reduce)').matches,duration:.5});},[selected,map,spots]);
 useEffect(()=>{const observer=new ResizeObserver(()=>map.invalidateSize());observer.observe(map.getContainer());return()=>observer.disconnect();},[map]);return null;
}
export default function MapView({spots,selected,hovered,onSelect,route}:{spots:Spot[];selected:string|null;hovered:string|null;onSelect:(id:string)=>void;route:Spot[]}) {
 const [provider,setProvider]=useState<"google"|"overview">("google");
 const uniqueSpots=useMemo(()=>Array.from(new Map(spots.map(s=>[s.id,s])).values()),[spots]);
 const focusSpot=uniqueSpots.find(s=>s.id===selected)||uniqueSpots[0];
 const [tileError,setTileError]=useState(false);const [walking,setWalking]=useState<{distance:number;minutes:number;points:[number,number][]}|null>(null);const [routeState,setRouteState]=useState("");
 const pair=route.length>=2?[route[0],route[route.length-1]]:[];
 const km=pair.length?distanceKm(pair[0],pair[1]):0;
 const routeKey=pair.map(x=>x.id).join('|');
 useEffect(()=>{setWalking(null);setRouteState("");},[routeKey]);
 const icons=useMemo(()=>Object.fromEntries(spots.map(s=>[s.id,L.divIcon({className:"map-marker-wrapper",html:`<span class="map-marker category-${s.category}${s.id===selected||s.id===hovered?' selected':''}"><span></span></span>`,iconSize:[28,34],iconAnchor:[14,34],popupAnchor:[0,-32]})])),[spots,selected,hovered]);
 async function walkingRoute(){if(pair.length!==2)return;setRouteState("查询步行路线中…");setWalking(null);try{const url=`https://routing.openstreetmap.de/routed-foot/route/v1/foot/${pair[0].lng},${pair[0].lat};${pair[1].lng},${pair[1].lat}?overview=full&geometries=geojson`;const res=await fetch(url,{signal:AbortSignal.timeout(12000)});if(!res.ok)throw Error();const json=await res.json();const r=json.routes?.[0];if(!r||!Number.isFinite(r.distance)||!Number.isFinite(r.duration)||!Array.isArray(r.geometry?.coordinates))throw Error();setWalking({distance:r.distance/1000,minutes:Math.round(r.duration/60),points:r.geometry.coordinates.map((p:number[])=>[p[1],p[0]])});setRouteState("来自 OSM 社区路线服务，现场以道路状况为准");}catch{setRouteState("路线服务暂时不可用，地图仍显示直线连接；可打开导航查询。");}}
 return <div className="map-shell"><div className="map-heading"><MapPin size={16}/><span>在地图上，找到下一站</span><small>{uniqueSpots.length} 个地点</small></div>
 <div className="map-provider"><button onClick={()=>setProvider('google')} aria-pressed={provider==='google'}>Google 地图</button><button onClick={()=>setProvider('overview')} aria-pressed={provider==='overview'}>全部地点总览</button>{focusSpot&&<MapLinks spot={focusSpot}/>}</div>
 {provider==='google'?<div className="google-map-view">{focusSpot?<><label>当前地点<select aria-label="Google 地图当前地点" value={focusSpot.id} onChange={e=>onSelect(e.target.value)}>{uniqueSpots.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label><iframe title={`${focusSpot.name} Google 地图`} src={`https://maps.google.com/maps?q=${focusSpot.lat},${focusSpot.lng}&z=14&hl=zh-CN&output=embed`} loading="lazy" allowFullScreen referrerPolicy="no-referrer-when-downgrade"/><p>Google 网页地图需联网；苹果地图按钮可在 iPhone 打开系统地图。完整交通路线请点下方导航。</p></>:<p>请选择景点查看地图。</p>}</div>:<>
 <MapContainer center={[35.68,139.76]} zoom={11} scrollWheelZoom={false} className="leaflet-map" aria-label="日本景点互动地图">
   <GeoJSON attribution='出典: 地球地図日本（国土地理院） / dataofjapan' data={geography as GeoJsonObject} style={{color:'#c7d0c8',weight:1,fillColor:'#ecefe7',fillOpacity:.7}}/>
   <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" eventHandlers={{tileerror:()=>setTileError(true)}}/>
   <Camera spots={spots} selected={selected}/>
   {uniqueSpots.map(s=><Marker title={s.name} alt={`${s.name}地图标记`} key={s.id} position={[s.lat,s.lng]} icon={icons[s.id]} eventHandlers={{click:()=>onSelect(s.id)}}><Popup><strong>{s.name}</strong><br/>{s.ja}<br/>{s.station}<br/>门票参考：{s.priceKnown===false?"待核价":<Money yen={s.price}/>}<br/><MapLinks spot={s}/></Popup></Marker>)}
   {route.length>=2&&<Polyline positions={route.map(s=>[s.lat,s.lng])} pathOptions={{color:'#b5443c',weight:2,dashArray:'7 7'}}/>}
   {walking&&<Polyline positions={walking.points} pathOptions={{color:'#407761',weight:4}}/>}
 </MapContainer></>}
 {provider==='overview'&&tileError&&<p className="map-network-note" role="status">街道底图加载受限；保留日本边界与景点坐标。联网后刷新可重试。</p>}
 <div className="map-route"><Route size={17}/><div>{pair.length===2?<><strong>{pair[0].name} → {pair[1].name}</strong><p>直线约 {km.toFixed(1)} 公里{walking?` · 实路步行 ${walking.distance.toFixed(1)} 公里 / 约 ${walking.minutes} 分钟`:" · 虚线不是实际交通路线"}</p><div className="route-actions">{km<=30&&<button onClick={walkingRoute} disabled={routeState.startsWith("查询")}>查询实路步行</button>}<MapLinks spot={pair[1]} origin={pair[0]} walking={km<3}/></div>{routeState&&<p role="status">{routeState}</p>}</>:<><strong>点选景点，查看位置</strong><p>点击卡片联动 Google 地图；“全部地点总览”用 OpenStreetMap 显示多个坐标与直线距离。</p></>}</div></div>
 </div>;
}
