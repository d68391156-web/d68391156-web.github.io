'use client';
import {useState} from 'react';
import {useCurrency} from './CurrencyProvider';
const areas=[
['东京','御徒町','JR御徒町站','优先','上野、秋叶原近；JR山手／京滨东北线，加上野御徒町、仲御徒町地铁。','羽田京急→品川转JR，或单轨→滨松町转JR。','阿美横丁、平价餐馆方便；独行友好，避开临主路及酒吧楼层。'],
['东京','上野','JR上野站','备选','JR与多条地铁便于浅草、东京站；车站大，要确认出口。','羽田经品川／滨松町转JR；成田路线不用于本次机场预算。','餐饮选择多；注意御徒町与上野站之间步行距离及夜间街区。'],
['东京','秋叶原','JR秋叶原站','备选','动漫电器购物与JR方便；去西部景点需换乘或较长乘车。','羽田经品川／滨松町转JR。','商圈晚间人多，选有储物柜及夜间入口管理的青旅。'],
['大阪','大国町','大阪地铁大国町站','优先','御堂筋线、四桥线；难波一站，新大阪方向较方便。','至难波换南海前往关西机场，带大箱需留站内步行。','常有居民区小店；偏安静，确认青旅前台、女性／混合宿舍类型。'],
['大阪','南海难波','南海难波站','优先','关西机场出入方便；近铁大阪难波站便于奈良，但并非同一入口。','南海机场急行或Rapi:t至KIX，特急另购券。','购物餐饮集中；选错出口可能多走，核对电梯与夜间噪声。'],
['大阪','心斋桥','大阪地铁心斋桥站','备选','购物方便，御堂筋线至新大阪或难波；京都往返另转JR／阪急。','地铁至难波换南海。','衣物商场多，周末夜间较热闹；注意青旅静音规则。'],
['大阪','日本桥','近铁日本桥站','备选','近铁、地铁及黑门市场便利；去难波和电电城可步行。','至南海难波步行或短程地铁，按住宿位置核对。','餐饮、市场便利；确认日本桥与大阪难波的步行距离，勿误订东京日本桥。']
];
export function HostelAreas(){const [nightly,setNightly]=useState(180);const {quote}=useCurrency();return <section className="planning-panel"><h2>青年旅馆选址 · 先看交通，再比较整段总价</h2><p>东京1/24–1/29共5晚，大阪1/29–2/4共6晚。东京御徒町、大阪大国町或难波优先；1/23不订东京酒店，在羽田允许区域休息至首班交通。</p><label className="field-label">每晚个人预算参考（CNY，非酒店报价）<input type="number" min="1" max="10000" value={nightly} onChange={e=>{const v=Number(e.target.value);if(v>=1&&v<=10000)setNightly(v);}}/></label><p>东京5晚 ¥{nightly*5} · 大阪6晚 ¥{nightly*6} · 共¥{nightly*11}。{quote?`约每晚${Math.round(nightly/quote.rate)}日元，按上方汇率；不代表有房。`:'未获汇率时仅列人民币预留。'}此处比较参考，不会覆盖总预算中的住宿单价。</p><div className="guide-grid">{areas.map(([city,name,station,priority,transit,airport,life])=><article className="quote-card" key={name}><small>{city} · {priority} · 待预订</small><h3>{name}</h3><p><b>车站与步行：</b>{station}。筛选站口步行5–10分钟内的青年旅馆；具体分钟数须按所选旅馆地图路线核对，不代表本区所有旅馆都在此范围。</p><p><b>景点交通：</b>{transit}</p><p><b>机场：</b>{airport}</p><p><b>独行与环境：</b>{life}</p><p><b>预订前：</b>确认行李寄存是否收费、退房后能否存放、储物柜尺寸、上下铺、浴室、清洁费和城市税；凌晨到达不保证提前入住。比较含税整段价与取消政策。</p><a href={'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(city+' '+station+' 青年旅館')} target="_blank" rel="noreferrer">查看车站及周边青年旅馆地图 ↗</a></article>)}</div><p>未获取实时空房／价格，以上是区域比较与预算目标。下方沿用三平台查价、报价录入和11晚抵扣功能；真实整单报价必须填写来源及查询时间。</p></section>;}
