# 2027核心方案：核验范围

新默认01-25至02-07，东京5、京都3、大阪5晚，近郊当日往返。已有缓存不自动覆盖。核心计划的地点顺序、时刻、住宿与日期可编辑，河口湖可与东京日互换；实际已订交通须另改期。环球影城和布引香草园不进入正式计划。

新增32处资料分离保存在additional-spots.json；未逐项核实的价格／开放时间／学生优惠明确待核，不宣称完整旅行数据库。原42处及图片、地图、11天历史、机票酒店报价和汇率功能保留。照片复用城市授权图，明确为示意，未生成伪实景。

交通8条路线17种方案均为规划预留，不是2027已开售车次和票价。夜巴节省住宿为独立情景，仅在用户确认取消条件后显示，不自动更改真实酒店报价。实际账本不重复叠加到预计总额。

核对日2026-11-01：
- 退税：海关 https://www.customs.go.jp/kaigairyoko/taxrefund.htm ，国税厅 https://www.nta.go.jp/publication/pamph/shohi/menzei/201805/format/002.htm 。新制先含税付款，出境确认后退款；税前同店同日5000、次日起90日内确认，托运前按机场指示查验。手续费由商家／退款方决定。
- 按用户最新要求移除ISIC办卡及费用计算，保留普通学生票资格提醒。
- 八坂 https://www.yasaka-jinja.or.jp/event/setsubun/ ：常规2/2–3节分，未确认2027专属场次。
- 布引 https://www.kobeherb.com/infomation/hours_fare/ ：2027-01-23至02-19计划检修；中文页结束日期不同，均覆盖02-05。
- 缆车 https://www.mtfujiropeway.jp/en/guide/ ：个人成人往返自2026-11-01为1200JPY，学生团体不适用于单人。
- 东京塔 https://www.tokyotower.co.jp/fee/index.html 、金阁寺 https://www.shokoku-ji.jp/kinkakuji/access/ 、梅田 https://www.skybldg.co.jp/observatory/information/ 、神户港塔 https://www.kobe-port-tower.com/ticket/ ：票种范围与核对日见数据，不代表2027保证开放。

验证结果见QA.md。保留GitHub Actions静态导出构建和main部署机制；本地构建成功与公网部署成功分别报告。当前集成写入403，未推送、未创建PR、未上线。
