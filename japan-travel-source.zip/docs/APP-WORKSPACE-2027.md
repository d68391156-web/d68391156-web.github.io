# 2027自由行完整工作台

继续使用原Next.js16.4.3／React项目，未创建新仓库、未新增依赖或后端。保留原样式及已实现功能。移动优先CSS含390、760、1100断点与深色模式；真实iPhone/iPad未实测，不将Mac检查当作真机验证。

## 路线及风险

核心方案2027-01-24至02-05。东京御徒町青旅5晚、大阪大国町／难波青旅6晚。1/23不订东京酒店，1/24凌晨在羽田允许区域停留至首班。河口湖、伊豆可换日，酒店日期固定。京都、奈良大阪往返；镰仓、神户、京都住宿及直飞长沙不进入正式方案。

东京1/27按短停时长设置08:00、10:00、12:00、14:15、16:00、18:15。这是建议排程，排队、商店开门及实际交通可能延误。京都保留8处确定地点，清水寺仅为可选。日内visitMinutes作为可验证的逐日短停覆盖，通用景点时长保持。

## 官方入口核对（2026-11-08）

- 羽田首末班：https://www.haneda-tokyo-access.com/en/haneda-airport/nightandmorning.html
- 河口湖高速巴士：https://bus.fujikyu.co.jp/en/highway/fujisan/shinjuku-kawaguchiko/
- 踊子号：https://www.jreast.co.jp/en/multi/traininformation/odoriko/index.html
- 新干线：https://smart-ex.jp/en/
- 京都JR：https://www.westjr.co.jp/global/sc/；近铁奈良：https://www.kintetsu.co.jp/foreign/chinese-han/
- 关西南海：https://www.howto-osaka.com/en/
- 港铁口岸：https://www.mtr.com.hk/en/customer/services/to_from_lw_lmc.html
- 12306：https://www.12306.cn/；现行15天预售期：https://help.12306.cn/cms/answer/h5/001531826595438842083440b580b2e0 。2027调整、实际起售时刻与余票未确认，不保证衔接。
- ROND：https://hiramatsurestaurant.jp/nacc-rond/ 。现列11:00–18:00、17:30最后点单，不接受预约、现场等位，周二休息（节假日顺延）；2027临时日历另核。
- 都厅：https://www.yokoso.metro.tokyo.lg.jp/ 。公开检索显示临时开闭室可能变化，正文访问403，本次未确认2027开放。
- 日本海关：https://www.customs.go.jp/kaigairyoko/taxrefund.htm 。现列2026-11-01后退款制、同店同日税前5000日元、90天内离境确认；2027出发前再次核对。已在日本使用／消费的物品不保证可退，净退款另看商家手续费。

## 金额与状态

机票、火车票、酒店全待预订。交通与青旅金额为规划预留，不是实核报价／余票。官方入口核对时间不等于票价实核时间，界面明确尚未核价。无付费API，无虚构航班号、确认订单或酒店库存。

预算总计沿用原引擎，实际支出单列比较；港币快照手动录入；选中报价不改变付款状态。购物已买只改变购物清单，不自动写账本。逐日住宿按个人总住宿费均摊至11个日本住宿日期，机票等全程费用不强行分摊。

## 数据与兼容

旧浏览器计划不静默覆盖，可在总览载入最新确定方案并撤销。机票／酒店报价独立保存，旧条件需重新同步。新增购物键japan-shopping-v1，主题键japan-theme；原账本键、行程键和报价键保留。导入检查字段、日期、金额、ID重复及短停时长。

所有91个地点照片路径和内容均不重复；原授权保留，49张新图补齐作者／许可／来源及指纹。全站无新增远程字体，图片本地懒加载，地图按页面动态加载。
