# 三平台住宿查价核验 · 2026-11-01

本次以公开页面跳转及用户手动录价实现，未接入平台实时报价 API。没有采购、订房、登录注册、签约、绕过验证码或调用未公开内部接口。

## 公开城市入口依据

| 城市 | Trip.com 官方城市 URL（包含真实城市编号） | Agoda 官方城市 URL |
|---|---|---|
| 东京 | https://www.trip.com/hotels/tokyo-hotels-list-228/ | https://www.agoda.com/en-us/city/tokyo-jp.html |
| 京都 | https://www.trip.com/hotels/kyoto-hotels-list-734/ | https://www.agoda.com/en-us/city/kyoto-jp.html |
| 大阪 | https://www.trip.com/hotels/osaka-hotels-list-219/ | https://www.agoda.com/en-us/city/osaka-jp.html |

以上六个官方城市页均有公开搜索结果佐证；不从城市名称猜数字 ID。其他城市暂回退平台首页，并提示补填及复制条件。

Booking.com 的日期和入住人数参数依据官方重定向示例：
https://developers.booking.com/demand/docs/accommodations/accommodation-tutorial
https://developers.booking.com/demand/docs/accommodations/search-examples

这些示例证明公开跳转 URL 中使用 checkin、checkout、group_adults、no_rooms 及 selected_currency 等字段，但不等于本项目搜索链接所有参数都已经被当前网页版接受。搜索城市采用公开搜索页 ss 文本，不编造 dest_id，不添加假 affiliate ID。URLSearchParams 统一编码城市与数值，含 &、/、空格的城市文本不会成为额外参数。

## 实际浏览器打开记录

测试条件：东京，2027-01-25 入住、01-30 退房，1 成人、1 房、无儿童。

1. 直接打开 Trip.com 东京官方城市页，浏览器标题为 `10 Best Tokyo Hotels, Japan (from US$56) | Trip.com`；读取搜索控件及 DOM 连续超时。只确认城市页打开，不确认日期或人数带入。最终项目按钮保留该城市 URL，不附加未核实参数。
2. 直接打开 Agoda 东京官方城市页，浏览器自动转到中文城市页，标题为 `日本东京自由行十大精选酒店| Agoda®`；读取控件超时。不确认日期或人数带入，最终项目按钮只定位城市。
3. 打开 Booking.com 带日期、成人数和房间数的东京搜索 URL。浏览器标题为 `搜索东京酒店_东京酒店查询_Booking.com缤客`，随后 URL 出现 chal_t 和 force_referer，控件读取与截图超时。未获得搜索栏日期或人数的可见证据，不宣称已验证参数接受，不对访问挑战做绕过。
4. 在最终本地构建中实际点击三个平台按钮，分别生成新标签页；Booking.com 此次 ss 使用 `东京, 日本`。确认三条生成链接可打开新标签页，但再次读取 Booking 页面超时，参数实际接受状态仍标为未确认。

| 平台 | 本次确认 | 本次未确认 / 用户需处理 |
|---|---|---|
| Trip.com | 东京公开城市页打开；三核心城市路径来自官方公开页 | 日期、成人及房间数需手填；仅东京实际浏览器打开，京都大阪未逐一浏览器验收 |
| Agoda | 东京公开城市页打开并重定向中文；三核心城市路径来自官方公开页 | 日期、成人及房间数需手填；仅东京实际浏览器打开，京都大阪未逐一浏览器验收 |
| Booking.com | 东京搜索页打开；网站生成链接成功在新标签页打开 | 日期、人数、房间数及币种接受情况未确认，平台可能要求验证或重新搜索 |

没有依据证明的参数不列为“成功带入”。网页已逐平台列出需补填条件，并提供一键复制和可选中文本备用。链接本身不提供价格，网站不会显示虚构实时房价或库存。

## 正式接口后续条件（仅记录，未申请）

- Trip.com Partner API：合作伙伴凭据及签名：https://apidoc.trip.com/apidoc
- Agoda：伙伴凭据、认证及上线流程：https://developer.agoda.com/demand/docs/getting-started
- Booking.com：Managed Affiliate Partner、合同后 Partner Centre、API Key 和 Affiliate ID：https://developers.booking.com/demand/docs/getting-started/prerequisites

获得权限后仍需按具体合同核对价格比较、内容展示和缓存限制，并通过后端保护密钥；本次没有注册、接受协议或建立此类连接。
