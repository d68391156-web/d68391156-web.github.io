# 恢复调查 · 2026-11-01

远程： https://github.com/d68391156-web/d68391156-web.github.io

已完整 Git clone，并检查全部远程分支、8 个提交的文件树以及 Actions 最近发布记录。只有 main 分支，最新提交 `21906b996a69546b705a2082d08ab261d9e3b4aa`。8 个提交中只有 README、静态 ZIP、base64 更新包和 Pages 工作流，无 Next.js / TypeScript 开发源码。最近发布 run `40282861201` 状态 completed / success（2026-10-26）。

历史（从新到旧）：

- 21906b9 Label visit duration clearly in Chinese
- 6b0b2ff Add dedicated Kobe, Kamakura, Nara and nearby city filters
- e2f733e Update pages.yml
- b5c6d43 Create currency-update.b64
- 9b0336e Clarify ticket prices, add booking details and Google/Apple Maps
- 577eb2c Create pages.yml
- d46d2b7 Upload complete Japan travel guide and 42 attraction photos
- 60f0486 Initial commit

本机保存了前次维护的完整 Next.js 工程：`/Users/dengjincheng/Documents/Codex/2026-10-19/files-mentioned-by-the-user-img/outputs/japan-winter-trip`。本次复制其开发文件到交付目录，未修改该历史工程。其之前 `out/index.html` 与远程最新更新包中的首页字节完全相同。

远程原始 ZIP 的 Git blob SHA 为 `bc2c7ba5ccae32f3412ab07bf5f72c9d43f0c61f`。共 93 个文件，解压完整性通过。包含编译后的 HTML、RSC 文本、CSS、JavaScript、图片和 handbook，无 `.ts` / `.tsx` / package.json。远程更新包 blob 为 `922e188922b08568944af90f437c420411c6a255`，base64 解码为 37 文件 ZIP，完整性通过；覆盖首页与构建静态资源。

比对 56 项图片 / 原手册资源，交付项目 public 中的全部 56 项均与远程原始 ZIP 字节相同。42 个景点及其坐标、文案、地图、预约与图片授权直接保留。详细资产清单见 `asset-audit.json`。

这是复用本机保存源码后的升级，不是从混淆或编译 JavaScript 完整反向恢复原始源码。新增规划引擎、报价和预算模块为本次实现。

资料核对：

- 二条城官方：https://nijo-jocastle.city.kyoto.lg.jp/guide/annai/
- 香港入境处：https://www.immd.gov.hk/eng/services/visas/visit_transit.html
- 韩国签证官方核对入口：https://www.visa.go.kr/

开放窗口和交通价格为规划参数，不宣称全部在本次重新实时核价。景点原始核对日期 2026-10-26 保留。
