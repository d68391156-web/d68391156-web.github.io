# 机票联网查询与签证费纠正 · 2026-11-01

## 签证费用纠正

此前 `initialBudget.visa = 400` 是未经来源支持的“签证及代办总价”默认值，不适合继续使用。现已改为以下可核对结构：

- 一般单次签证官方规费：人民币 715 元。
- 一般多次签证官方规费：人民币 1430 元。
- 生效日期：2026-07-01，按正式受理时政策核对，不保证未来申请标准不变。
- 代办服务费：未知留空，不视作免费；另列用户询价 / 手动预留与来源。
- 照片、快递等其他费用：单列可编辑预留。

主要来源：日本国驻华大使馆《赴日签证 Q&A》，核对 2026-11-01：
https://www.cn.emb-japan.go.jp/itpr_zh/visa_qa.html

交叉核对：日本国驻上海总领事馆《2026年7月1日签证费用修改》，说明旧一般单次 145 元调整为 715 元、旧多次 285 元调整为 1430 元：
https://www.shanghai.cn.emb-japan.go.jp/itpr_ja/11_000001_00633.html

湖南位于驻华大使馆领区，实际根据居住地及代办要求确认：
https://www.cn.emb-japan.go.jp/itpr_ja/consular.html

旧缓存中的签证合计保留为 `legacyVisaTotal`，不静默删除，也不继续当作官方标准。新计算按上述规费及独立服务费计入。服务费未知或未填来源时，总预算明确显示待核，不宣称预算已足够。签证分项及来源包含于预算导出。

## 联网获取的真实机票参考数据

来源：Skyscanner 连接器的 Flights Indicative Prices 月份查询，获取时间为 2026-11-01 16:48:40 北京时间。

必须注明来源及入口：
https://skyscanner.net/g/referrals/v1/flights/home?mediaPartnerId=2850210&utm_term=skyscanner_chatgpt_app_data

查询一：2027 年 1 月 CSX → TYO，单程，CNY，返回 8 条记录。
查询二：2027 年 2 月 KIX → CSX，单程，CNY，返回 5 条记录。
原始结构中的金额、日期、机场、承运人、是否直达和官方 referral URL 已保存在 `data/flight-research.json`。

这些是**缓存指示价，不是当前实时票价、余票或预订承诺**。平台未提供本次结果的原始采集时间、完整税费细项、具体转机时间或行李额度，均未补造。两条航线的查询日期覆盖一个月，不是当前默认去返程日期的精确报价。

本次没有返回默认去程 2027-01-25 或返程 2027-02-07 的同日价格；未返回不等于无航班。记录中的其他日期低价不能拼接成本次 14 天路线的往返总价，未自动计入预算。

Skyscanner 指示价说明：
https://developers.skyscanner.net/docs/flights-indicative-prices/overview

## 网站机票查价功能

- 可编辑去程 / 返程日期、出境与回到的机场、日本进出机场和成人数。
- 机场选项含长沙 CSX、香港 HKG、青岛 TAO、上海浦东 PVG、广州 CAN、深圳 SZX、仁川 ICN，以及东京 TYO / NRT / HND、大阪 KIX / OSA。
- 去回程按独立航段生成 Skyscanner 日期查询 URL，URL schema 来自连接器实际返回的公开 referral 链接，不调用私有端点。链接附带日期及航线，人数和是否接受条件需在平台核对。
- 东京进大阪出同时提供完整多程条件复制；单程拆分不等于多程 / 联程最低总价。非长沙出境还需核算国内或跨境接驳。
- 韩国选项查询完整 CSX → 日本 / 日本 → CSX，并提示在平台筛选仁川中转；不把 ICN 接驳错误归为国内交通，不声称查询 URL 锁定中转点。
- 提供 Trip.com、携程、Google Flights 入口及按当前日期机场生成的公开网络搜索。
- 保留手动往返报价、行李接驳等全程成本排序；单人总预算应录入本人费用，不能把多人总价未分摊直接计入。

Trip.com、Google Flights 等公开网页的“起价”或其他日期价格未挪用为本次报价。参考公开航线依据：
https://www.trip.com/flights/changsha-to-tokyo/airfares-csx-tyo/
https://www.trip.com/flights/hong-kong-to-tokyo/airfares-hkg-tyo/
https://www.google.com/travel/flights/flights-from-osaka-to-changsha.html

## 已知范围

本网站仍为静态 GitHub Pages 工程，没有嵌入本人的 Skyscanner 连接器权限、私人凭据或平台 API key，不能在所有访问者浏览器中自动持续调用连接器刷新价格。它能显示本次有时间戳的联网记录，并将用户送到平台按当前条件查价；未将缓存参考伪装成站内实时接口。

机票与签证之外的费用也明确区分：酒店、饮食等默认值是手动预留；景点和交通沿用既有核对日期的参考资料，不宣称这次全部完成实时重新核价。正式预订和送签前请复核原来源。
