# 2026-11-08 照片去重与伊豆补充

89个地点使用89张不同内容的本地照片。保留原42张，替换后加42个地点的复用图，新增5张伊豆照片。授权与作者逐项见public/images/credits.json和credits.html。照片年份、季节不等同旅行当天；咖啡馆外观和三得利照片仅为体验参考。

## 伊豆资料来源

- 樱之里： https://www.pref.shizuoka.jp/kurashikankyo/shizenkankyo/sakura/1057743/1058518/1058521.html
- 动物公园及水豚： https://izushaboten.com/animal/kapibara/
- 一碧湖及步道封闭提示： https://itospa.com/spot/detail_54018.html
- 小室山及巴士／缆车入口： https://www.tokaibus.jp/business/komuroyama_pack.html
- 伊东海洋城： https://www.itospa.com/spot/detail_50001.html

2026-11-08核对。2027营业、运行、票价及活动场次需出发前复核。东京往返一日游建议选择2–3处，不自动追加到核心方案，避免赶路；山顶强风停运时小室山也不能保证运行。
