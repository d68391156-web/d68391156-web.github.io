"use client";
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { defaultTrip, spotById } from "./catalog";
import { coreTrip } from "../data/core-trip";
import { generateTrip } from "./planning";
import { defaultStays } from "../data/planning-rules";
import { validateTrip } from "./travel";
import { SLOTS, type Trip, type Slot } from "./types";
function cloneDefault():Trip{return structuredClone(defaultTrip);}
function sortItems(items:Trip["days"][number]["items"]){return items.map((item,i)=>({item,i})).sort((a,b)=>SLOTS.indexOf(a.item.slot)-SLOTS.indexOf(b.item.slot)||a.i-b.i).map(x=>x.item);}
type State={setIntercity:(id:string,yen:number)=>void;setDayInfo:(id:string,title:string,stay:string)=>void;alternateTrip:Trip|null;replaceTrip:(t:Trip)=>void;swapTrip:()=>void;trip:Trip;checks:Record<string,boolean>;activeDay:string;setActiveDay:(id:string)=>void;addSpot:(spotId:string,dayId:string,slot:Slot)=>void;removeItem:(dayId:string,itemId:string)=>void;moveItem:(itemId:string,targetDay:string,slot:Slot,beforeId?:string)=>void;setTime:(dayId:string,itemId:string,time:string)=>void;setTransit:(dayId:string,value:number)=>void;setTripInfo:(title:string,startDate:string)=>void;addDay:()=>void;reset:()=>void;importTrip:(t:Trip)=>void;toggleCheck:(id:string)=>void;};
export const useTripStore=create<State>()(persist((set)=>({
alternateTrip:null,
setIntercity:(id,yen)=>{if(!Number.isFinite(yen)||yen<0||yen>1000000)return;set(s=>({trip:{...s.trip,days:s.trip.days.map(d=>d.id===id?{...d,intercity:yen}:d)}}));},
setDayInfo:(id,title,stay)=>set(s=>({trip:{...s.trip,days:s.trip.days.map(d=>d.id===id?{...d,title:title.slice(0,100),stay:stay.slice(0,200)}:d)}})),
replaceTrip:trip=>{const valid=validateTrip(trip);if(valid)set(s=>({alternateTrip:structuredClone(s.trip),trip:structuredClone(valid),activeDay:valid.days[0].id}));},
swapTrip:()=>set(s=>s.alternateTrip?{trip:s.alternateTrip,alternateTrip:s.trip,activeDay:s.alternateTrip.days[0].id}:s),
trip:coreTrip(),checks:{},activeDay:"core-day-0",
setActiveDay:activeDay=>set({activeDay}),
addSpot:(spotId,dayId,slot)=>{if(!spotById.has(spotId))return;set(s=>({trip:{...s.trip,days:s.trip.days.map(d=>d.id!==dayId||d.items.length>=60?d:{...d,items:sortItems([...d.items,{id:crypto.randomUUID(),spotId,slot,time:slot==="morning"?"09:00":slot==="afternoon"?"14:00":"19:00"}])})}}));},
removeItem:(dayId,itemId)=>set(s=>({trip:{...s.trip,days:s.trip.days.map(d=>d.id===dayId?{...d,items:d.items.filter(x=>x.id!==itemId)}:d)}})),
moveItem:(itemId,targetDay,slot,beforeId)=>set(s=>{const original=s.trip.days.flatMap(d=>d.items).find(x=>x.id===itemId);if(!original||!s.trip.days.some(d=>d.id===targetDay))return s;const target=s.trip.days.find(d=>d.id===targetDay)!;const fromSame=target.items.some(x=>x.id===itemId);if(!fromSame&&target.items.length>=60)return s;
 const days=s.trip.days.map(d=>({...d,items:d.items.filter(x=>x.id!==itemId)}));const d=days.find(x=>x.id===targetDay)!;const changed={...original,slot};const at=beforeId?d.items.findIndex(x=>x.id===beforeId):-1;if(at>=0)d.items.splice(at,0,changed);else d.items.push(changed);d.items=sortItems(d.items);return {trip:{...s.trip,days}};}),
setTime:(dayId,itemId,time)=>{if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))return;set(s=>({trip:{...s.trip,days:s.trip.days.map(d=>d.id===dayId?{...d,items:d.items.map(i=>i.id===itemId?{...i,time}:i)}:d)}}));},
setTransit:(dayId,value)=>{if(!Number.isFinite(value)||value < -1||value>1000000)return;set(s=>({trip:{...s.trip,days:s.trip.days.map(d=>d.id===dayId?{...d,transit:Math.round(value)}:d)}}));},
setTripInfo:(title,startDate)=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(startDate)||!Number.isFinite(new Date(startDate).getTime()))return;set(s=>({trip:{...s.trip,title:title.slice(0,100),startDate}}));},
addDay:()=>set(s=>s.trip.days.length>=31?s:{trip:{...s.trip,days:[...s.trip.days,{id:crypto.randomUUID(),title:"自由探索",city:"待定",stay:"待定",transit:-1,transportNote:"",items:[]}]}}),
reset:()=>set({trip:cloneDefault(),activeDay:defaultTrip.days[0].id}),
importTrip:trip=>{const valid=validateTrip(trip);if(valid)set({trip:structuredClone(valid),activeDay:valid.days[0].id});},
toggleCheck:id=>set(s=>({checks:{...s.checks,[id]:!s.checks[id]}})),
}),{name:"japan-planner-v2",version:2,storage:createJSONStorage(()=>localStorage),skipHydration:true,partialize:s=>({alternateTrip:s.alternateTrip,trip:s.trip,checks:s.checks,activeDay:s.activeDay}),merge:(persisted,current)=>{const p=persisted as Partial<State>|undefined;if(!p)return current;const valid=validateTrip(p.trip);const checks=p.checks&&typeof p.checks==="object"?Object.fromEntries(Object.entries(p.checks).filter(([k,v])=>k.length<100&&typeof v==="boolean")):{};return {...current,alternateTrip:validateTrip(p.alternateTrip),trip:valid||current.trip,checks,activeDay:valid?.days.some(d=>d.id===p.activeDay)?p.activeDay!:current.activeDay};}}));
