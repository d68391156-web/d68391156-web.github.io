'use client';
import {create} from 'zustand';
import {persist,createJSONStorage} from 'zustand/middleware';
import {validSearch,validHotelQuote,type HotelSearch,type HotelQuote} from './hotels';
type HotelsState={search:HotelSearch|null;quotes:HotelQuote[];selected:string[];setSearch:(s:HotelSearch)=>void;clearSearch:()=>void;addQuote:(q:HotelQuote)=>boolean;removeQuote:(id:string)=>void;toggleQuote:(id:string)=>void};
export const useHotelStore=create<HotelsState>()(persist((set,get)=>({
  search:null,quotes:[],selected:[],
  setSearch:search=>{if(validSearch(search))set({search});},clearSearch:()=>set({search:null}),
  addQuote:q=>{const s=get();if(!validHotelQuote(q)||s.quotes.length>=100||s.quotes.some(x=>x.id===q.id))return false;set({quotes:[...s.quotes,q]});return true;},
  removeQuote:id=>set(s=>({quotes:s.quotes.filter(q=>q.id!==id),selected:s.selected.filter(x=>x!==id)})),
  toggleQuote:id=>set(s=>({selected:s.selected.includes(id)?s.selected.filter(x=>x!==id):s.quotes.some(q=>q.id===id)?[...s.selected,id]:s.selected})),
}),{name:'japan-hotels-v1',version:1,storage:createJSONStorage(()=>localStorage),skipHydration:true,
  partialize:s=>({search:s.search,quotes:s.quotes,selected:s.selected}),
  merge:(raw,current)=>{const p=raw as Partial<HotelsState>|null;const quotes=Array.isArray(p?.quotes)?p.quotes.filter(validHotelQuote).slice(0,100).filter((q,i,a)=>a.findIndex(x=>x.id===q.id)===i):[];
    return {...current,search:validSearch(p?.search)?p.search:null,quotes,selected:Array.isArray(p?.selected)?[...new Set(p.selected.filter((id):id is string=>typeof id==='string'&&quotes.some(q=>q.id===id)))]:[]};},
}));
