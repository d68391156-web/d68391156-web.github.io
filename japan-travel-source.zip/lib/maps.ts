import type { Spot } from './types';
type Point = Pick<Spot,'lat'|'lng'|'name'>;
export function mapLink(provider:'google'|'apple',point:Point,origin?:Point,walking=false){
 const position=`${point.lat},${point.lng}`;
 if(provider==='google'){
  const params=new URLSearchParams({api:'1',...(origin?{origin:`${origin.lat},${origin.lng}`,destination:position,travelmode:walking?'walking':'transit'}:{query:position})});
  return `https://www.google.com/maps/${origin?'dir/':'search/'}?${params}`;
 }
 const params=new URLSearchParams(origin?{saddr:`${origin.lat},${origin.lng}`,daddr:position,dirflg:walking?'w':'r'}:{ll:position,q:point.name});
 return `https://maps.apple.com/?${params}`;
}
