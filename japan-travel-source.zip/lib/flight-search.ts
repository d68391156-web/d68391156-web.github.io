import {isDate} from './planning';
export const flightGateways=[{name:'长沙',iata:'CSX'},{name:'香港',iata:'HKG'},{name:'青岛',iata:'TAO'},{name:'上海浦东',iata:'PVG'},{name:'广州',iata:'CAN'},{name:'深圳',iata:'SZX'},{name:'韩国仁川',iata:'ICN'}] as const;
export const japanAirports=[{name:'东京（全市机场）',iata:'TYO'},{name:'东京成田',iata:'NRT'},{name:'东京羽田',iata:'HND'},{name:'大阪关西',iata:'KIX'},{name:'大阪（全市机场）',iata:'OSA'}] as const;
export type FlightSearch={outbound:string;inbound:string;gateway:string;returnGateway:string;entry:string;exit:string;adults:number};
export function flightSearchError(s:FlightSearch){
 if(!isDate(s.outbound)||!isDate(s.inbound)||s.inbound<s.outbound||s.outbound<'2020-01-01'||s.inbound>'2100-12-31')return '请填写有效日期，返程不得早于去程';
 if(!flightGateways.some(g=>g.iata===s.gateway)||!flightGateways.some(g=>g.iata===s.returnGateway)||!japanAirports.some(g=>g.iata===s.entry)||!japanAirports.some(g=>g.iata===s.exit))return '请选择列表中的出境及日本机场';
 if(!Number.isInteger(s.adults)||s.adults<1||s.adults>9)return '成人数须为 1–9';return '';
}
export function validFlightSearch(x:unknown):x is FlightSearch{return !!x&&typeof x==='object'&&!flightSearchError(x as FlightSearch);}
export function skyscannerFlightLink(from:string,to:string,date:string){
 if(!/^[A-Z]{3}$/.test(from)||!/^[A-Z]{3}$/.test(to)||!isDate(date))throw Error('无效的航线或日期');
 // Public referral schema returned by the Skyscanner connector, not a private search endpoint.
 const u=new URL('https://skyscanner.net/g/referrals/v1/flights/day-view');
 u.search=new URLSearchParams({mediaPartnerId:'2850210',utm_term:'skyscanner_chatgpt_app_data',origin:from,destination:to,outboundDate:date,cabinclass:'economy',locale:'zh-CN',currency:'CNY',market:'CN'}).toString();return u.toString();
}
export function flightLegs(s:FlightSearch){
 if(flightSearchError(s))return [];
 const from=s.gateway==='ICN'?'CSX':s.gateway,to=s.returnGateway==='ICN'?'CSX':s.returnGateway;
 return [{label:'去程国际段',from,to:s.entry,date:s.outbound,url:skyscannerFlightLink(from,s.entry,s.outbound),note:s.gateway==='ICN'?'请在平台筛选仁川中转；链接不锁定中转点。':''},{label:'返程国际段',from:s.exit,to,date:s.inbound,url:skyscannerFlightLink(s.exit,to,s.inbound),note:s.returnGateway==='ICN'?'请在平台筛选仁川中转；链接不锁定中转点。':''}];
}
export function matchesFlightRecord(q:{date:string;from?:string;to?:string},leg:{date:string;from:string;to:string}){
 const airportMatch=(wanted:string,actual?:string)=>wanted===actual||(wanted==='TYO'&&['NRT','HND'].includes(actual||''))||(wanted==='OSA'&&['KIX','ITM'].includes(actual||''));
 return q.date===leg.date&&airportMatch(leg.from,q.from)&&airportMatch(leg.to,q.to);
}
export function copyFlightSearch(s:FlightSearch){return `日本机票查价（经济舱，${s.adults} 位成人）\n去程：${s.outbound} ${s.gateway==='ICN'?'CSX':s.gateway} → ${s.entry}${s.gateway==='ICN'?'（在平台筛选经仁川 ICN）':''}\n返程：${s.inbound} ${s.exit} → ${s.returnGateway==='ICN'?'CSX':s.returnGateway}${s.returnGateway==='ICN'?'（在平台筛选经仁川 ICN）':''}\n实际出发及回到长沙 CSX；非长沙出境时需另核国内 / 跨境接驳。韩国接驳属于国际航段，应优先查完整联程，不能当作国内交通费。\n东京进大阪出应按多程 / 缺口程同时核价；拆开查询两个单程不保证最低或联程保障。\n请核对含税总价、行李、候机转机、机场交通、住宿及过境条件；查询链接人数仍需在平台确认。`;}
export function flightWebSearch(s:FlightSearch){const q=`${s.outbound} ${s.gateway==='ICN'?'CSX 经ICN':s.gateway} ${s.entry} ${s.inbound} ${s.exit} ${s.returnGateway==='ICN'?'经ICN CSX':s.returnGateway} 机票 含税 行李 ${s.adults}成人`;return 'https://www.google.com/search?'+new URLSearchParams({q}).toString();}
