import { spots, spotById } from './catalog';
import { tripDate, distanceKm } from './travel';
import { cityOrder, windows, transitRules, type PlanningCity } from '../data/planning-rules';
import type { Trip, Spot, DayPlan } from './types';
export function isDate(value:string){return /^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value+'T12:00:00Z'))&&new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value;}
export function nijoClosed(date:string){const d=new Date(date+'T12:00:00Z');return ([1,7,8,12].includes(d.getUTCMonth()+1)&&d.getUTCDay()===2)||(d.getUTCMonth()===0&&d.getUTCDate()<=3)||(d.getUTCMonth()===11&&d.getUTCDate()>=26);}
export function transfer(a:string,b:string){if(a===b)return {minutes:0,yen:0,mode:'同城'};return transitRules[a+'|'+b]||transitRules[b+'|'+a]||{minutes:300,yen:15000,mode:'跨城交通待核对；暂预留 5 小时'};}
export function localMinutes(a:Spot,b:Spot){if(a.city!==b.city)return transfer(a.city,b.city).minutes;const km=distanceKm(a,b);return Math.max(20,Math.ceil((km<1.2?km/4*60:km/20*60+25)/5)*5);}
export function clock(minutes:number){return `${Math.floor(minutes/60).toString().padStart(2,'0')}:${(minutes%60).toString().padStart(2,'0')}`;}
export function generateTrip(startDate:string,days:number,stays:Record<PlanningCity,number>):Trip {
 if(!isDate(startDate)||!Number.isInteger(days)||days<2||days>31)throw Error('日期或天数无效（2–31 天）');
 if(cityOrder.some(c=>!Number.isInteger(stays[c])||stays[c]<0)||Object.values(stays).reduce((a,b)=>a+b,0)!==days)throw Error('城市停留天数合计须等于旅行天数');
 const cities=cityOrder.flatMap(c=>Array.from({length:stays[c]},()=>c));
 const used=new Set<string>();const result:DayPlan[]=[];
 for(let i=0;i<days;i++){
  const city=cities[i],date=tripDate(startDate,i),travel=i?transfer(cities[i-1],city):{minutes:180,yen:0,mode:'抵日当天预留入境和机场接驳 3 小时；请按实际航班调整'};
  let cursor=(i===0?600:540)+travel.minutes;const end=i===days-1?780:1200;
  const candidates=spots.filter(s=>s.city===city&&s.id!=='kobe-herb'&&!used.has(s.id)&&!(s.id==='nijo'&&nijoClosed(date)));
  const items:DayPlan['items']=[];let previous:Spot|undefined;
  for(const s of candidates){
   const [open,close]=windows[s.id]||[540,1200];const begin=Math.max(open,cursor+(previous?localMinutes(previous,s):0));
   if(begin+s.duration>Math.min(close,end)||items.length>=3)continue;
   items.push({id:`generated-${i}-${s.id}`,spotId:s.id,slot:begin<720?'morning':begin<1080?'afternoon':'evening',time:clock(begin)});used.add(s.id);cursor=begin+s.duration+30;previous=s;
  }
  result.push({id:`generated-day-${i}`,city,title:city+(i===0?' · 抵达':i===days-1?' · 返程':''),stay:i===days-1?'返程日，无日本住宿':city==='镰仓'?'镰仓 / 东京（按实际预订）':city==='奈良'?'奈良 / 大阪（按实际预订）':city+'经济型住宿（待预订）',transit:travel.yen+(items.length?800:0),transportNote:`${travel.mode}，预留 ${travel.minutes} 分钟；费用为规划估算。\n${i===days-1?'返程日下午预留机场接驳、值机和候机，请核对实际起飞时间。':'景点间按距离预留交通和 30 分钟休息；非实时换乘。'}\n${items.length?'':'当天保留自由探索 / 交通机动；不重复塞入已安排景点。'}`,items});
 }
 return {title:`长沙出发 · 日本 ${days} 天自由行`,startDate,days:result};
}
export function scheduleWarnings(trip:Trip,index:number){
 const day=trip.days[index],date=tripDate(trip.startDate,index);const out:string[]=[];
 let previous:Spot|undefined,previousEnd=0;
 if(index){
 const prev=trip.days[index-1];
 const base=['东京','京都','大阪','镰仓','河口湖','奈良','神户','箱根','横滨'].find(c=>prev.stay.includes(c))||prev.city.split(' · ')[0];
 const leg=base===day.city?{minutes:0,mode:'同城'}:base==='东京'&&day.city==='河口湖'?{minutes:150,mode:'高速巴士及接驳，天气与路况待核'}:transfer(base,day.city);
 if(leg.minutes){previousEnd=(['镰仓','河口湖','伊豆','京都','奈良','神户'].includes(day.city)?360:540)+leg.minutes;out.push(`跨城需预留 ${leg.minutes} 分钟：从前夜住宿地${base}出发，${leg.mode}。时间为规划估算。`);}
 }

 for(const item of day.items){const s=spotById.get(item.spotId)!;const begin=Number(item.time.slice(0,2))*60+Number(item.time.slice(3));const end=begin+s.duration;const [open,close]=windows[s.id]||[0,1440];
 if(s.id==='nijo'&&nijoClosed(date))out.push('二条城二之丸御殿可能休止（1/7/8/12 月周二、年末年初；节假日顺延以官网为准），请换日或仅参观开放区域。');
 if(begin<open||end>close)out.push(`${s.name}：当前时刻可能超出规划开放窗口；原资料：${s.hours}`);
 if(begin<previousEnd+(previous?localMinutes(previous,s):0))out.push(`${s.name}：与前一站 / 跨城交通时间冲突，需顺延或移至其他日期。`);
 if(!day.city.split(' · ').includes(s.city))out.push(`${s.name}位于${s.city}，与当天城市${day.city}不同，请核对跨城交通及住宿。`);
 previous=s;previousEnd=end;
 }return out;
}
