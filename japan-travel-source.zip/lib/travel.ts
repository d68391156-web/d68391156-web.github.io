import { moneyText, type CurrencyMode, type ExchangeQuote } from "./currency";
import type { DayPlan, Spot, Trip, RouteQuote } from "./types";
import { spotById } from "./catalog";
export function distanceKm(a: Pick<Spot,"lat"|"lng">, b: Pick<Spot,"lat"|"lng">) {
  const r=Math.PI/180, dlat=(b.lat-a.lat)*r, dlng=(b.lng-a.lng)*r;
  const h=Math.sin(dlat/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dlng/2)**2;
  return 6371.0088*2*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0,1-h)));
}
export const railRoutes: RouteQuote[] = [
  {id:"tokyo-kyoto",from:"东京",to:"京都",cost:13650,jrEligible:true,minutes:160,note:"Hikari 通常期指定席参考，非 Nozomi"},
  {id:"odawara-kyoto",from:"小田原",to:"京都",cost:12100,jrEligible:true,minutes:140,note:"Hikari 通常期指定席参考"},
  {id:"kyoto-osaka",from:"京都",to:"大阪",cost:580,jrEligible:true,minutes:30,note:"JR 新快速参考，不是新干线"},
  {id:"osaka-hiroshima",from:"大阪",to:"广岛",cost:10950,jrEligible:true,minutes:100,note:"新大阪出发 Sakura 参考，日期待查"},
  {id:"kyoto-nara",from:"京都",to:"奈良",cost:800,jrEligible:true,minutes:45,note:"JR 奈良线参考预算"},
  {id:"osaka-kobe",from:"大阪",to:"神户",cost:500,jrEligible:true,minutes:30,note:"JR 新快速参考预算"},
  {id:"shinjuku-hakone",from:"东京",to:"箱根",cost:2470,jrEligible:false,minutes:90,note:"小田急 Romancecar，不属 JR"},
  {id:"tokyo-sapporo",from:"东京",to:"札幌",cost:0,jrEligible:false,minutes:0,note:"本工具不估飞机票；自行查询，不计入省钱比较"},
];
export function transferEstimate(a:Spot,b:Spot) {
  const km=distanceKm(a,b); if(km<1.2)return 0;
  if(a.city===b.city)return km<5?240:km<15?350:600;
  const match=railRoutes.find(r=>[r.from,r.to].includes(a.city)&&[r.from,r.to].includes(b.city));
  return match?.cost ?? (km<30?500:km<70?1000:km<150?2500:Math.round(km*28/100)*100);
}
export function dayCosts(day:DayPlan) {
  const s=day.items.map(i=>spotById.get(i.spotId)).filter((x):x is Spot=>!!x);
  const tickets=s.reduce((n,x)=>n+x.price,0);
  const autoTransit=s.slice(1).reduce((n,x,i)=>n+transferEstimate(s[i],x),0);
  const transit=day.transit<0?autoTransit:day.transit;
  return {tickets,transit,total:tickets+transit,autoTransit};
}
export function tripDate(start:string, index:number) {
  const d=new Date(start+"T12:00:00Z");d.setUTCDate(d.getUTCDate()+index);
  return d.toISOString().slice(0,10);
}
export function validateTrip(input:unknown):Trip|null {
  if(!input||typeof input!=="object")return null;
  const t=input as Trip;
  if(typeof t.title!=="string"||t.title.length>100||typeof t.startDate!=="string"||!/^\d{4}-\d{2}-\d{2}$/.test(t.startDate))return null;
  const date=new Date(t.startDate+"T12:00:00Z");if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==t.startDate)return null;
  if(!Array.isArray(t.days)||t.days.length<1||t.days.length>31)return null;
  const ids=new Set<string>();const itemIds=new Set<string>();
  for(const d of t.days){
    if(!d||typeof d.id!=="string"||ids.has(d.id)||d.id.length>80)return null;ids.add(d.id);
    if(![d.title,d.city,d.stay,d.transportNote].every(x=>typeof x==="string"&&x.length<10000))return null;
    if(d.intercity!==undefined&&(!Number.isFinite(d.intercity)||d.intercity<0||d.intercity>1000000))return null;
    if(!Number.isFinite(d.transit)||d.transit < -1||d.transit>1000000)return null;
    if(!Array.isArray(d.items)||d.items.length>60)return null;
    for(const i of d.items){if(!i||typeof i.id!=="string"||i.id.length>80||itemIds.has(i.id)||!spotById.has(i.spotId)||!["morning","afternoon","evening"].includes(i.slot)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(i.time))return null;itemIds.add(i.id);}
  }return t;
}
export function jrComparison(routes:{routeId:string;count:number}[],days:7|14,channel:"official"|"agency") {
 const pass=channel==="official"?(days===7?50000:80000):(days===7?53000:84000);
 let total=0,eligible=0;for(const r of routes){const q=railRoutes.find(x=>x.id===r.routeId);if(q){total+=q.cost*r.count;if(q.jrEligible)eligible+=q.cost*r.count;}}
 return {pass,total,eligible,saving:eligible-pass,withPass:pass+(total-eligible)};
}
export function markdownTrip(trip:Trip,currency?:{mode:CurrencyMode;quote:ExchangeQuote|null}) {
 const money=(yen:number)=>moneyText(yen,currency?.mode||"JPY",currency?.quote||null);
 const lines=[`# ${trip.title.replace(/[\r\n]/g," ")}`,`出发日期：${trip.startDate}`,"票价与交通为参考预算；非预订凭证。",currency?.quote?`汇率：100 日元 ≈ ${(currency.quote.rate*100).toFixed(4)} 人民币；数据时间 ${currency.quote.observedAt}；来源 ${currency.quote.source}；${currency.quote.kind==='intraday'?'日内报价约延迟15分钟':'每日参考价'}。`:"未获取联网汇率，仅列日元原价。",""];
 trip.days.forEach((d,i)=>{const c=dayCosts(d);lines.push(`## Day ${i+1} · ${tripDate(trip.startDate,i)} · ${d.title}`,`住宿：${d.stay}`,`门票 ${money(c.tickets)} + 交通 ${money(c.transit)} = ${money(c.total)}`,"");for(const item of d.items){const s=spotById.get(item.spotId)!;lines.push(`- ${item.time} ${s.name} / ${s.ja} — ${s.station}，门票参考 ${s.priceKnown===false?"待核价":money(s.price)}；参观建议用时：${s.duration} 分钟`);if(s.booking)lines.push(`  - 预约：${s.booking.status}。${s.booking.advance}`,`  - 办理：${s.booking.where}；${s.booking.url}`,`  - ${s.booking.note}`);}lines.push("","交通与换乘：",d.transportNote||"按实际出发位置查询交通。","");});return lines.join("\n");
}
