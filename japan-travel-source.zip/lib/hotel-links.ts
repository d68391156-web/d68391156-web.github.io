import {searchError,type HotelSearch,type HotelPlatform} from './hotels';
// Only city URLs evidenced by the public platform pages are mapped. No inferred numeric IDs.
export const hotelCityPages:Record<string,{trip:string;agoda:string}>={
  京都:{trip:'https://www.trip.com/hotels/kyoto-hotels-list-734/',agoda:'https://www.agoda.com/en-us/city/kyoto-jp.html'},
  大阪:{trip:'https://www.trip.com/hotels/osaka-hotels-list-219/',agoda:'https://www.agoda.com/en-us/city/osaka-jp.html'},
  东京:{trip:'https://www.trip.com/hotels/tokyo-hotels-list-228/',agoda:'https://www.agoda.com/en-us/city/tokyo-jp.html'},
};
export function hotelLinks(s:HotelSearch):Array<{platform:HotelPlatform;url:string;note:string}> {
  if(searchError(s))return [];
  const city=hotelCityPages[s.city.trim()];
  const booking=new URL('https://www.booking.com/searchresults.html');
  booking.search=new URLSearchParams({ss:s.city.trim()+', 日本',checkin:s.checkin,checkout:s.checkout,group_adults:String(s.adults),no_rooms:String(s.rooms),group_children:'0',selected_currency:'CNY'}).toString();
  return [
    {platform:'Trip.com',url:city?.trip||'https://www.trip.com/hotels/',note:city?'城市酒店入口；日期、成人数、房间数需在平台填写（未确认自动带入）':'未维护此城市的已核实平台 ID；请在平台填写城市、日期、成人数及房间数'},
    {platform:'Agoda',url:city?.agoda||'https://www.agoda.com/',note:city?'城市酒店入口；日期、成人数、房间数需在平台填写（未确认自动带入）':'未维护此城市的已核实平台入口；请在平台填写城市、日期、成人数及房间数'},
    {platform:'Booking.com',url:booking.toString(),note:'已附带城市文本、日期、成人数及房间数；实际接受情况尚未确认，请在平台搜索栏逐项复核；访问受限时复制条件手填'},
  ];
}
