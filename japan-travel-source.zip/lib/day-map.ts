import type {Spot,Trip} from './types';
import {tripDate} from './travel';
import {spotById} from './catalog';
export const dayColors=['#b94338','#336f9f','#377752','#8b5ca1','#966516','#146f7a','#a34876','#4b6790','#658023','#a05c37','#6960a5','#19765f','#7f5a43'];
export type DayMapGroup={id:string;label:string;color:string;spots:Spot[]};
export function dayMapGroups(trip:Trip):DayMapGroup[]{return trip.days.map((d,i)=>({id:d.id,label:`第${i+1}天 · ${tripDate(trip.startDate,i)} · ${d.title}`,color:dayColors[i%dayColors.length],spots:d.items.map(x=>spotById.get(x.spotId)).filter((s):s is Spot=>!!s)}));}
export function googleDayRoute(spots:Spot[]){if(!spots.length)return 'https://www.google.com/maps/';const u=new URL('https://www.google.com/maps/dir/');const point=(s:Spot)=>`${s.lat},${s.lng}`;u.search=new URLSearchParams({api:'1',origin:point(spots[0]),destination:point(spots.at(-1)!),travelmode:'transit'}).toString();return u.toString();}
