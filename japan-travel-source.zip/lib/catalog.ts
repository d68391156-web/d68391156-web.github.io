import catalog from "@/data/japan-spots.json";
import additional from "@/data/additional-spots.json";
import handbook from "@/data/original-handbook.json";
import type { Spot, Trip, Slot } from "./types";
export const spots = [...catalog, ...additional] as Spot[];
export const spotById = new Map(spots.map(s => [s.id, s]));
export const bookings = handbook.bookings;
const schedule: [string, Slot, string][][] = [
  [["kabukicho","evening","19:00"],["godzilla","evening","20:00"]],
  [["sensoji","morning","08:00"],["skytree","afternoon","12:00"],["akihabara","evening","16:00"]],
  [["meiji","morning","09:00"],["harajuku","afternoon","12:00"],["hachiko","afternoon","14:00"],["shibuya-sky","afternoon","15:30"],["suntory","evening","18:30"]],
  [["kamakura-buddha","morning","09:00"],["hasedera","morning","10:00"],["kamakura-coast","afternoon","13:00"],["yokohama","evening","17:00"]],
  [["kawaguchiko","morning","10:00"]],
  [["hakone","afternoon","12:00"],["hakone-onsen","evening","16:00"]],
  [["kiyomizu","afternoon","14:00"],["gion","evening","17:00"]],
  [["fushimi","morning","07:00"],["nijo","afternoon","12:00"],["nishiki","afternoon","15:00"],["kamogawa","evening","17:00"]],
  [["nara-park","morning","09:00"],["todaiji","morning","10:30"],["dotonbori","evening","18:00"],["shinsaibashi","evening","19:30"]],
  [["kobe-kitano","morning","10:00"],["kobe-port","afternoon","14:00"],["umeda","evening","18:00"]],
  [["kuromon","morning","09:00"]],
];
export const defaultTrip: Trip = {
  title: "冬日东海道 · 11 天 10 晚", startDate: "2027-01-23",
  days: handbook.days.map((d,i) => ({ id: `day-${i+1}`, title: d.city, city: d.city, stay: d.stay,
    transit: [1000,1050,750,3300,5900,8110,13000,1100,2000,1850,1250][i],
    transportNote: d.routes.join("\n"),
    items: schedule[i].map(([spotId,slot,time],j) => ({id:`initial-${i}-${j}`,spotId,slot,time})),
  })),
};
