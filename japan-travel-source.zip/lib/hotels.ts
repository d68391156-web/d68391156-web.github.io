import type {Trip} from './types';
import {tripDate} from './travel';
import {isDate} from './planning';
import {safeUrl} from './flight-budget';

export const hotelPlatforms = ['Trip.com','Agoda','Booking.com'] as const;
export type HotelPlatform = typeof hotelPlatforms[number];
export type HotelSearch = {city:string;checkin:string;checkout:string;adults:number;rooms:number};
export type HotelQuote = HotelSearch & {
  id:string;platform:HotelPlatform;hotel:string;roomType:string;sourceUrl:string;
  total:number;currency:'CNY'|'JPY'|'HKD'|'USD';rate:number;rateSource:string;
  breakfast:string;cancellation:string;extraFees:string;queriedAt:string;
  sharePeople:number;basis:'整段住宿全部房间含税总价';
};
export function hotelNights(checkin:string,checkout:string){
  if(!isDate(checkin)||!isDate(checkout))return 0;
  return (Date.parse(checkout+'T00:00:00Z')-Date.parse(checkin+'T00:00:00Z'))/86400000;
}
export function searchError(s:HotelSearch):string {
  if(typeof s.city!=='string'||!s.city.trim()||s.city.length>80)return '请填写目的地城市（最多 80 字）';
  const n=hotelNights(s.checkin,s.checkout);
  if(n<1||n>365||s.checkin<'2020-01-01'||s.checkout>'2100-12-31')return '入住与退房须为有效日期，退房晚于入住，最多 365 晚';
  if(!Number.isInteger(s.adults)||s.adults<1||s.adults>16||!Number.isInteger(s.rooms)||s.rooms<1||s.rooms>8||s.rooms>s.adults)return '成人数须为 1–16，房间数须为 1–8 且不多于成人数';
  return '';
}
export function validSearch(x:unknown):x is HotelSearch {
  if(!x||typeof x!=='object')return false;
  return !searchError(x as HotelSearch);
}
const text=(x:unknown,max=1000)=>typeof x==='string'&&x.trim().length>0&&x.length<=max;
export function validHotelQuote(x:unknown):x is HotelQuote {
  if(!validSearch(x))return false;const q=x as HotelQuote;
  return hotelPlatforms.includes(q.platform)&&text(q.id,80)&&text(q.hotel,150)&&text(q.roomType,150)
    &&text(q.sourceUrl,2000)&&safeUrl(q.sourceUrl)&&['CNY','JPY','HKD','USD'].includes(q.currency)
    &&Number.isFinite(q.total)&&q.total>0&&q.total<=1000000&&Number.isFinite(q.rate)&&q.rate>0&&q.rate<=100
    &&(q.currency!=='CNY'||q.rate===1)&&text(q.rateSource,200)&&text(q.breakfast,200)
    &&text(q.cancellation)&&text(q.extraFees)&&typeof q.queriedAt==='string'&&Number.isFinite(Date.parse(q.queriedAt))
    &&Date.parse(q.queriedAt)<=Date.now()+300000&&Number.isInteger(q.sharePeople)&&q.sharePeople>=1&&q.sharePeople<=q.adults
    &&q.basis==='整段住宿全部房间含税总价';
}
export const hotelCny=(q:HotelQuote)=>Math.round(q.total*q.rate*100)/100;
export const hotelShare=(q:HotelQuote)=>Math.round(hotelCny(q)/q.sharePeople*100)/100;
export function hotelComparisonKey(q:HotelQuote){
  return JSON.stringify([q.city.trim().toLocaleLowerCase(),q.checkin,q.checkout,q.adults,q.rooms,q.roomType.trim(),q.breakfast.trim(),q.cancellation.trim(),q.extraFees.trim(),q.basis]);
}
export function groupHotelQuotes(quotes:HotelQuote[]) {
  const groups=new Map<string,HotelQuote[]>();
  for(const q of quotes){const key=hotelComparisonKey(q);groups.set(key,[...(groups.get(key)||[]),q]);}
  return [...groups.values()].map(g=>g.sort((a,b)=>hotelCny(a)-hotelCny(b)));
}
const knownCities=['东京','京都','大阪','镰仓','箱根','奈良','神户','横滨','河口湖','札幌','小樽','那霸','北谷'];
export const japanHotelDates=(trip:Trip)=>trip.days.slice(0,-1).flatMap((day,i)=>day.stay.includes('无日本住宿')?[]:[tripDate(trip.startDate,i)]);
export function staySuggestions(trip:Trip):Array<HotelSearch&{note:string}> {
  const result:Array<HotelSearch&{note:string}>=[];
  trip.days.slice(0,-1).forEach((day,i)=>{
    if(day.stay.includes('无日本住宿'))return;
    const match=knownCities.filter(c=>day.stay.includes(c));
    const city=match[0]||day.city.split(/[ ·/]/)[0]||'东京';
    const note=match.length===1?'由当天住宿说明提取，仍需确认':`住宿地待确认：${day.stay}`;
    const date=tripDate(trip.startDate,i),last=result.at(-1);
    if(last&&last.city===city&&last.checkout===date&&last.note===note)last.checkout=tripDate(trip.startDate,i+1);
    else result.push({city,checkin:date,checkout:tripDate(trip.startDate,i+1),adults:1,rooms:1,note});
  });
  return result;
}
export function copyHotelSearch(s:HotelSearch){
  return `日本住宿查价\n目的地：${s.city}\n入住：${s.checkin}\n退房：${s.checkout}\n${hotelNights(s.checkin,s.checkout)} 晚 · ${s.adults} 位成人 · ${s.rooms} 间房 · 无儿童\n请比较整段住宿全部房间含税总价，并核对早餐、取消政策及到店额外费用。`;
}
export function hotelAllocation(trip:Trip,quotes:HotelQuote[],selected:string[],nightly:number){
  const covered=new Set<string>(),applied:string[]=[],issues:string[]=[];let quoted=0;
  const eligible=new Set(japanHotelDates(trip));
  const end=tripDate(trip.startDate,trip.days.length-1);
  for(const id of [...new Set(selected)]){
    const q=quotes.find(x=>x.id===id);
    if(!q||!validHotelQuote(q)){issues.push('某条已选住宿报价无效或已删除，未计入预算');continue;}
    if(q.checkin<trip.startDate||q.checkout>end){issues.push(`${q.hotel}：日期超出当前行程住宿区间，整条报价暂不计入`);continue;}
    const nights=Array.from({length:hotelNights(q.checkin,q.checkout)},(_,i)=>tripDate(q.checkin,i));
    if(nights.some(d=>!eligible.has(d))){issues.push(`${q.hotel}：覆盖非日本住宿夜晚，整条报价暂不计入`);continue;}
    if(nights.some(d=>covered.has(d))){issues.push(`${q.hotel}：与另一已选报价住宿夜晚重叠，整条报价暂不计入`);continue;}
    nights.forEach(d=>covered.add(d));applied.push(id);quoted+=hotelShare(q);
  }
  const uncovered=Math.max(0,eligible.size-covered.size),reserve=uncovered*nightly;
  return {total:Math.round((quoted+reserve)*100)/100,quoted:Math.round(quoted*100)/100,reserve,coveredNights:covered.size,uncoveredNights:uncovered,applied,issues};
}
