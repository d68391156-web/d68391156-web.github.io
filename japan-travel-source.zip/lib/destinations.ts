import type { Region, Spot } from './types';
export const destinations:{name:Region;en:string}[]=[
 {name:'东京',en:'Tokyo'},{name:'镰仓',en:'Kamakura'},{name:'横滨',en:'Yokohama'},
 {name:'河口湖',en:'Kawaguchiko'},{name:'伊豆',en:'Izu'},{name:'箱根',en:'Hakone'},{name:'京都',en:'Kyoto'},
 {name:'奈良',en:'Nara'},{name:'大阪',en:'Osaka'},{name:'神户',en:'Kobe'},
 {name:'北海道',en:'Hokkaido'},{name:'冲绳',en:'Okinawa'},{name:'周边',en:'All nearby cities'},
];
export function matchesDestination(spot:Spot,destination:Region){return destination==='全部'||spot.city===destination||spot.region===destination;}
