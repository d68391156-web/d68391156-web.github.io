export type CurrencyMode='both'|'JPY'|'CNY';
export type ExchangeQuote={rate:number;observedAt:string;fetchedAt:string;source:'exchangerate.dev'|'Frankfurter';kind:'intraday'|'daily';market:string;stale:boolean};
export function validQuote(input:unknown):input is ExchangeQuote{
 if(!input||typeof input!=='object')return false;const q=input as ExchangeQuote;
 return Number.isFinite(q.rate)&&q.rate>0.001&&q.rate<1&&['exchangerate.dev','Frankfurter'].includes(q.source)&&['intraday','daily'].includes(q.kind)&&typeof q.stale==='boolean'&&typeof q.market==='string'&&Number.isFinite(Date.parse(q.observedAt))&&Number.isFinite(Date.parse(q.fetchedAt))&&Date.parse(q.fetchedAt)<=Date.now()+300000;
}
export function parseQuote(raw:unknown,source:ExchangeQuote['source'],now=new Date().toISOString()):ExchangeQuote{
 if(!raw||typeof raw!=='object')throw Error('无效汇率');const d=raw as Record<string,unknown>;if(d.base!=='JPY'||d.quote!=='CNY')throw Error('汇率币种不匹配');
 const q:ExchangeQuote={rate:Number(d.rate),observedAt:String(source==='exchangerate.dev'?d.data_updated_at:d.date+'T00:00:00Z'),fetchedAt:now,source,kind:source==='exchangerate.dev'&&d.source==='live'?'intraday':'daily',market:String(d.market_session||'daily'),stale:d.stale===true};
 if(source==='exchangerate.dev'&&d.result!=='success'||!validQuote(q))throw Error('无效汇率');return q;
}
export function moneyText(jpy:number,mode:CurrencyMode,quote:ExchangeQuote|null){
 const yen=`JP¥${Math.round(jpy).toLocaleString('zh-CN')}`;
 const yuan=jpy===0?'CN¥0.00':quote?`约 CN¥${(jpy*quote.rate).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2})}`:'人民币待获取汇率';
 return mode==='JPY'?yen:mode==='CNY'?(quote||jpy===0?yuan:`${yen}（人民币待获取）`):`${yen} / ${yuan}`;
}
