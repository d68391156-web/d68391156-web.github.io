import {isDate} from './planning';
export type ShoppingItem={id:string;name:string;style:string;sku:string;size:string;city:string;yen:number;rate:number;bought:boolean;date:string};
export function parseShopping(x:unknown):ShoppingItem[]{if(!Array.isArray(x)||x.length>500||x.some(r=>!r||!['id','name','style','sku','size','city','date'].every(k=>typeof r[k]==='string'&&r[k].length<=200)||!r.id||!r.name||!isDate(r.date)||typeof r.bought!=='boolean'||!Number.isFinite(r.yen)||r.yen<0||r.yen>1e7||!Number.isFinite(r.rate)||r.rate<=0||r.rate>1)||new Set(x.map(r=>r.id)).size!==x.length)throw Error('购物清单字段无效或ID重复');return x;}
export function shoppingTotals(rows:ShoppingItem[]){return rows.reduce((a,r)=>{a[r.bought?'paid':'pending']+=r.yen*r.rate;return a;},{paid:0,pending:0});}
