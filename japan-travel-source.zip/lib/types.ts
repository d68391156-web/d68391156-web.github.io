export const REGIONS = ["全部", "东京", "京都", "大阪", "北海道", "冲绳", "周边", "神户", "镰仓", "奈良", "河口湖", "伊豆", "箱根", "横滨"] as const;
export type Region = typeof REGIONS[number];
export const SLOTS = ["morning", "afternoon", "evening"] as const;
export type Slot = typeof SLOTS[number];
export const SLOT_NAMES: Record<Slot, string> = { morning: "上午", afternoon: "下午", evening: "晚上" };
export type Spot = {
  id: string; name: string; ja: string; en: string; region: Region; city: string;
  lat: number; lng: number; category: "landmark" | "temple" | "food" | "onsen" | "transit" | "nature";
  tags: string[]; seasons: string[]; budget: "免费" | "经济" | "体验";
  hours: string; price: number; priceNote: string; station: string; duration: number;
  priceKnown?: boolean; imageIllustration?: boolean; recommendedTime?: string; studentPolicy?: string;
  booking?: {status:string;advance:string;where:string;url:string;note:string;checkedAt:string};
  tips: string; image: string; photo?: { position?: string; alt: string; caption: string; source: string; author: string; license: string; licenseUrl: string }; source: string; checkedAt: string;
};
export type ItineraryItem = { id: string; spotId: string; slot: Slot; time: string };
export type DayPlan = { id: string; title: string; city: string; stay: string; intercity?:number; visitMinutes?:Record<string,number>; transit: number; transportNote: string; items: ItineraryItem[] };
export type Trip = { title: string; startDate: string; days: DayPlan[] };
export type RouteQuote = { id: string; from: string; to: string; cost: number; jrEligible: boolean; minutes: number; note: string };
