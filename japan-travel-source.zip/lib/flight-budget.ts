export const routes=['长沙','香港','青岛','上海','广州','深圳','韩国'] as const;
export type FlightRoute=typeof routes[number];
export type FlightQuote={id:string;route:FlightRoute;label:string;source:string;queriedAt:string;currency:'CNY'|'JPY'|'HKD'|'KRW';rate:number;fare:number;domestic:number;baggage:number;airport:number;overnight:number;flightHours:number;transferHours:number;domesticHours:number;baggageNote:string;throughTicket:boolean;url:string};
export const flightCost=(q:FlightQuote)=>(q.fare+q.baggage)*q.rate+q.domestic+q.airport+q.overnight;
export const flightHours=(q:FlightQuote)=>q.flightHours+q.transferHours+q.domesticHours;
export function safeUrl(url:string){try{const u=new URL(url);return u.protocol==='https:'&&!u.username&&!u.password;}catch{return false;}}
export function validateQuote(input:unknown):FlightQuote|null{
 if(!input||typeof input!=='object')return null;const q=input as FlightQuote;
 if(!routes.includes(q.route)||!['CNY','JPY','HKD','KRW'].includes(q.currency))return null;
 if(![q.id,q.label,q.source,q.queriedAt,q.baggageNote,q.url].every(s=>typeof s==='string'&&s.length<=2000)||!q.id||!q.label.trim()||!q.source.trim()||!q.baggageNote.trim())return null;
 if(!Number.isFinite(Date.parse(q.queriedAt))||Date.parse(q.queriedAt)>Date.now()+300000||typeof q.throughTicket!=='boolean'||!safeUrl(q.url))return null;
 if(![q.fare,q.domestic,q.baggage,q.airport,q.overnight,q.flightHours,q.transferHours,q.domesticHours].every(x=>Number.isFinite(x)&&x>=0&&x<=1000000)||q.fare<=0||!Number.isFinite(q.rate)||q.rate<=0||q.rate>100||q.currency==='CNY'&&q.rate!==1)return null;
 return q;
}
export function parseQuotes(input:unknown):FlightQuote[]{if(!Array.isArray(input)||input.length>100)throw Error('报价须为不超过 100 条的 JSON 数组');const all=input.map(validateQuote);if(all.some(q=>!q)||new Set(all.map(q=>q!.id)).size!==all.length)throw Error('报价字段不完整、ID 重复、金额 / 币种 / 查询时间或 HTTPS 链接无效');return all as FlightQuote[];}
export const budgetKeys=['hotelNight','foodDay','communication','visa','shopping','other','fallbackFlight','fallbackDomestic','fallbackAirport'] as const;
export type Budget=Record<typeof budgetKeys[number],number>&{limit:number;manualRate:number};
export const initialBudget:Budget={limit:10000,manualRate:0.05,hotelNight:180,foodDay:85,communication:100,visa:715,shopping:300,other:500,fallbackFlight:2500,fallbackDomestic:600,fallbackAirport:250};
export function validBudget(x:unknown):x is Budget{if(!x||typeof x!=='object')return false;const b=x as Budget;return [...budgetKeys,'limit','manualRate'].every(k=>Number.isFinite(b[k as keyof Budget])&&b[k as keyof Budget]>=0&&b[k as keyof Budget]<=1000000)&&b.limit>0&&b.manualRate>0&&b.manualRate<=1;}
export function calculateBudget(b:Budget,days:number,tickets:number,transit:number,rate:number,flight?:FlightQuote,hotelTotal?:number,intercityYen=0){
 const lines={往返机票:flight?(flight.fare+flight.baggage)*flight.rate:b.fallbackFlight,国内接驳:flight?flight.domestic:b.fallbackDomestic,机场接驳及转机住宿:flight?flight.airport+flight.overnight:b.fallbackAirport,酒店:hotelTotal ?? Math.max(0,days-1)*b.hotelNight,日本境内交通:Math.max(0,transit-intercityYen)*rate,新干线及夜间大巴:Math.min(Math.max(0,intercityYen),transit)*rate,饮食:days*b.foodDay,景点门票:tickets*rate,通信:b.communication,签证:b.visa,购物:b.shopping,预备金及其他:b.other};
 const total=Object.values(lines).reduce((a,b)=>a+b,0);return {lines,total,remaining:b.limit-total};
}
