import type {DayPlan} from './types';
import {spotById} from './catalog';
const routes:Record<string,[string,string,number,number,string]>={
'ueno|ameyoko':['上野公园出口 → 阿美横丁','步行，经JR上野站／御徒町一带',20,0,'0'],
'suga-shrine|meiji':['四谷三丁目 → 原宿／明治神宫前','丸之内线至新宿，转JR山手线至原宿，再步行',50,400,'1'],
'meiji|harajuku':['神宫南参道 → 竹下通','步行；按实际出口',20,0,'0'],
'harajuku|omotesando':['竹下通 → 表参道','街区步行，沿途商店自行取舍',25,0,'0'],
'omotesando|tocho':['表参道 → 都厅前','银座线至青山一丁目，转大江户线都厅前',45,400,'1'],
'tocho|kabukicho':['都厅前 → 新宿歌舞伎町','步行至新宿东口；过地下通道需核对出口',30,0,'0'],
'sensoji|akihabara':['浅草 → 末广町／秋叶原','银座线至末广町，再步行入商圈',35,300,'0'],
'akihabara|ginza':['秋叶原 → 有乐町／银座','JR山手／京滨东北线至有乐町后步行',35,300,'0'],
'ginza|rond-cafe':['银座 → 乃木坂','银座线至溜池山王，步行换千代田线至乃木坂；含馆内步行',50,400,'1'],
'rond-cafe|tokyo-tower':['六本木 → 赤羽桥','步行至六本木，大江户线至赤羽桥，步行到东京塔',45,350,'0'],
'tokyo-tower|hachiko':['赤羽桥 → 涩谷','大江户线至青山一丁目，转银座线至涩谷',50,400,'1'],
'fuji-lawson|fuji-ropeway':['河口湖站附近 → 缆车入口','按发车情况乘湖区巴士，或沿允许道路步行',40,500,'0'],
'fuji-ropeway|lake-kawaguchi':['缆车山麓站 → 湖畔','步行至湖畔开放区域，选近处午餐',30,0,'0'],
'lake-kawaguchi|oishi-park':['湖畔站点 → 河口湖自然生活馆／大石公园','湖区周游巴士，候车与末班另核',55,600,'0'],
'omuroyama|jogasaki':['大室山山麓 → 城崎海岸门胁吊桥','巴士经伊豆高原换乘，或另比较出租车；不建议按直线步行',100,1500,'1以上'],
'fushimi|sannenzaka':['伏见稻荷 → 清水五条／东山','京阪伏见稻荷至清水五条，再步行上坡；亦可核对巴士',60,500,'0–1'],
'sannenzaka|ninenzaka':['三年坂 → 二年坂','步行，台阶及拍照留缓冲',15,0,'0'],
'ninenzaka|yasaka':['二年坂 → 八坂神社','经东山街区步行',25,0,'0'],
'yasaka|gion':['八坂神社 → 祇园','步行至祇园街区',15,0,'0'],
'gion|hanamikoji':['祇园 → 花见小路','步行，尊重私巷与禁止摄影标志',15,0,'0'],
'hanamikoji|nishiki':['花见小路 → 锦市场','经四条大桥、河原町步行',30,0,'0'],
'nishiki|kamogawa':['锦市场 → 鸭川四条附近','步行返回河边；再按返程线路选择车站',20,0,'0'],
'osaka-castle|tsutenkaku':['森之宫／大阪城公园 → 新今宫','JR大阪环状线，再步行至通天阁；入园出口另留',50,400,'0'],
'tsutenkaku|shinsekai':['通天阁 → 新世界','同区步行',10,0,'0'],
'shinsekai|kuromon':['惠美须町 → 日本桥','堺筋线一站，再步行黑门市场；也可步行比较',30,300,'0'],
'nara-park|todaiji':['奈良公园 → 东大寺南大门／大佛殿','步行，含公园内缓冲',25,0,'0'],
'todaiji|kasuga':['东大寺 → 春日大社','公园步行，避免喂鹿耽误闭门时间',40,0,'0'],
'shinsaibashi|namba':['心斋桥 → 难波','沿商店街步行；购物时间不含在内',30,0,'0'],
'namba|dotonbori':['难波 → 道顿堀','街区步行',20,0,'0']
};
export function dayTransportLegs(day:DayPlan){return day.items.slice(1).map((item,i)=>{const a=spotById.get(day.items[i].spotId)!,b=spotById.get(item.spotId)!;const row=routes[a.id+'|'+b.id];return {from:a,to:b,stations:row?.[0]||`${a.station} → ${b.station}`,line:row?.[1]||'手动调整后的线路待核，请打开实际交通查询',minutes:row?.[2],yen:row?.[3],changes:row?.[4]||'待核',url:'https://www.google.com/maps/dir/?'+new URLSearchParams({api:'1',origin:`${a.lat},${a.lng}`,destination:`${b.lat},${b.lng}`,travelmode:'transit'}).toString()};});}
