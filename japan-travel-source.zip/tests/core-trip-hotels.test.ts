import test from 'node:test';
import assert from 'node:assert/strict';
import {coreTrip} from '../data/core-trip';
import {hotelAllocation,japanHotelDates} from '../lib/hotels';
test('return transit night is excluded from Japanese hotel reserve',()=>{const t=coreTrip();assert.equal(japanHotelDates(t).length,11);assert.equal(hotelAllocation(t,[],[],180).total,1980);});
