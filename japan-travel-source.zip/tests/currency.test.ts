import test from 'node:test';
import assert from 'node:assert/strict';
import {parseQuote,moneyText,validQuote} from '../lib/currency';
const now='2026-10-26T06:22:22Z';
const live={result:'success',base:'JPY',quote:'CNY',rate:0.042465,source:'live',data_updated_at:'2026-10-26T06:06:59Z',market_session:'open',stale:false};
test('JPY quote is converted in the correct direction and original cost is retained',()=>{
 const q=parseQuote(live,'exchangerate.dev',now);assert.equal(moneyText(3400,'both',q),'JP¥3,400 / 约 CN¥144.38');assert.equal(moneyText(3400,'CNY',q),'约 CN¥144.38');assert.equal(moneyText(3400,'JPY',q),'JP¥3,400');assert.equal(q.observedAt,live.data_updated_at);
});
test('missing rates do not turn paid activities into zero yuan',()=>{assert.match(moneyText(3400,'CNY',null),/JP¥3,400.*待获取/);assert.equal(moneyText(0,'CNY',null),'CN¥0.00');});
test('daily fallback preserves reference date and is not labelled intraday',()=>{const q=parseQuote({date:'2026-10-23',base:'JPY',quote:'CNY',rate:0.042},'Frankfurter',now);assert.equal(q.kind,'daily');assert.equal(q.observedAt,'2026-10-23T00:00:00Z');});
test('wrong currency pairs and corrupt cached quotes are rejected',()=>{assert.throws(()=>parseQuote({...live,base:'CNY',quote:'JPY'},'exchangerate.dev',now));for(const rate of [0,-1,NaN,Infinity,100])assert.throws(()=>parseQuote({...live,rate},'exchangerate.dev',now));assert.equal(validQuote({rate:0.04}),false);assert.throws(()=>parseQuote({...live,data_updated_at:'not-a-date'},'exchangerate.dev',now));});
