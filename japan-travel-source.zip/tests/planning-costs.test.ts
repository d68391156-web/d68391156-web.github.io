import test from 'node:test';
import assert from 'node:assert/strict';
import {generateTrip,scheduleWarnings,nijoClosed,isDate} from '../lib/planning';
// Retain a 14-day generator fixture independently of the new core itinerary.
const defaultStays={东京:5,镰仓:1,箱根:0,京都:4,奈良:1,大阪:3,神户:0};
import {validateTrip} from '../lib/travel';
import {initialBudget,calculateBudget,flightCost,parseQuotes,validateQuote,type FlightQuote} from '../lib/flight-budget';
test('14 day route has valid unique attractions and reserves departure day',()=>{
 const t=generateTrip('2027-01-25',14,defaultStays);assert.ok(validateTrip(t));assert.equal(t.days.length,14);assert.equal(t.days[0].city,'东京');assert.equal(t.days[13].city,'大阪');
 const ids=t.days.flatMap(d=>d.items.map(i=>i.spotId));assert.equal(new Set(ids).size,ids.length);
 assert.ok(t.days[13].items.every(x=>x.time<'13:00'));
 assert.deepEqual(t.days.flatMap((_,i)=>scheduleWarnings(t,i)).filter(x=>!x.startsWith('跨城需预留')),[]);
});
test('closure and editing warnings preserve itinerary but report conflicts',()=>{
 assert.ok(nijoClosed('2027-01-26'));assert.equal(nijoClosed('2027-02-02'),false);
 const t=generateTrip('2027-01-25',14,defaultStays);t.days[0].items=[{id:'x',spotId:'meiji',time:'20:00',slot:'evening'}];assert.ok(scheduleWarnings(t,0).some(s=>s.includes('开放窗口')));
});
test('invalid dates, lengths and mismatched stays rejected',()=>{assert.equal(isDate('2027-02-30'),false);assert.throws(()=>generateTrip('2027-01-25',13,defaultStays));assert.throws(()=>generateTrip('bad',14,defaultStays));assert.throws(()=>generateTrip('2027-01-25',14,{...defaultStays,大阪:NaN}));});
const quote:FlightQuote={id:'q',route:'香港',label:'测试报价',source:'测试手工输入',queriedAt:'2026-10-30T12:00:00+08:00',currency:'HKD',rate:.9,fare:2000,baggage:200,domestic:600,airport:200,overnight:0,flightHours:8,transferHours:5,domesticHours:6,baggageNote:'测试无真实票',throughTicket:false,url:'https://www.skyscanner.com/'};
test('flight all-in cost converts only fare and baggage, compares hidden costs',()=>{assert.equal(flightCost(quote),2780);const cheap={...quote,fare:1500,domestic:2000};assert.ok(flightCost(cheap)>flightCost(quote));});
test('imports reject malformed unsafe incomplete future and duplicate quotes',()=>{assert.ok(validateQuote(quote));for(const patch of [{fare:-1},{currency:'USD'},{url:'javascript:alert(1)'},{source:''},{rate:Infinity},{queriedAt:'2099-01-01'},{currency:'CNY',rate:.9}])assert.equal(validateQuote({...quote,...patch}),null);assert.throws(()=>parseQuotes([quote,quote]));assert.throws(()=>parseQuotes({}));});
test('budget covers all categories with 13 nights and selected quote replaces reserves',()=>{const c=calculateBudget(initialBudget,14,1000,20000,.05,quote);assert.equal(c.lines.酒店,13*180);assert.equal(c.lines.往返机票,1980);assert.equal(c.lines.国内接驳,600);assert.equal(c.lines.日本境内交通,1000);assert.equal(c.lines.饮食,1190);assert.equal(c.total,Object.values(c.lines).reduce((a,b)=>a+b,0));assert.equal(c.remaining,10000-c.total);assert.equal(calculateBudget({...initialBudget,limit:1},14,0,0,.05).remaining<0,true);});

test('switching historical trip preserves editable draft for undo',async()=>{const {useTripStore}=await import('../lib/store');const {defaultTrip}=await import('../lib/catalog');const original=generateTrip('2027-01-25',14,defaultStays);useTripStore.setState({trip:original,alternateTrip:null});useTripStore.getState().replaceTrip(defaultTrip);assert.equal(useTripStore.getState().trip.days.length,11);assert.equal(useTripStore.getState().alternateTrip?.days.length,14);useTripStore.getState().swapTrip();assert.equal(useTripStore.getState().trip.days.length,14);assert.equal(useTripStore.getState().alternateTrip?.days.length,11);});
test('optional Kobe stays precede Osaka departure and still pass validation',()=>{const t=generateTrip('2027-01-25',14,{...defaultStays,京都:3,神户:1});assert.ok(validateTrip(t));assert.equal(t.days.at(-1)?.city,'大阪');assert.ok(t.days.some(d=>d.city==='神户'));});
