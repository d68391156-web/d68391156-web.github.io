import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spots} from '../lib/catalog';
import credits from '../public/images/credits.json';
test('each destination has a distinct local photo by both path and file contents with attribution',()=>{
 const paths=new Set<string>(),hashes=new Set<string>();
 for(const spot of spots){
  assert.ok(!paths.has(spot.image),`Repeated photo path: ${spot.id}`);paths.add(spot.image);
  const hash=createHash('sha256').update(readFileSync('public'+spot.image)).digest('hex');
  assert.ok(!hashes.has(hash),`Repeated photo bytes: ${spot.id}`);hashes.add(hash);
  assert.ok(!spot.imageIllustration,`City placeholder: ${spot.id}`);
  const record=credits.images.find(x=>x.id===spot.id);
  assert.ok(record&&record.sha256===hash&&record.photo.author&&record.photo.licenseUrl,`Missing photo attribution: ${spot.id}`);
 }
});
test('Izu offers seven mapped choices while the fixed day remains flexible',()=>{
 const izu=spots.filter(s=>s.city==='伊豆');assert.equal(izu.length,7);
 for(const id of ['omuroyama','jogasaki','izu-sakura-sato','izu-shaboten','izu-ippekiko','izu-komuroyama','izu-marine-town'])assert.ok(izu.some(s=>s.id===id));
 for(const id of ['izu-shaboten','izu-komuroyama'])assert.equal(izu.find(s=>s.id===id)?.priceKnown,false);
});
