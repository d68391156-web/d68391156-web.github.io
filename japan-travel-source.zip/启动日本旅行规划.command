#!/bin/zsh
set -e
cd "$(dirname "$0")"
if [[ ! -f out/index.html ]]; then
  echo '缺少静态构建，请先运行 pnpm install 和 pnpm build。'
  read
  exit 1
fi
if curl -fsS http://127.0.0.1:8877/ 2>/dev/null | /usr/bin/grep -q '旅日'; then
  open http://127.0.0.1:8877/
  exit 0
fi
open http://127.0.0.1:8877/
python3 -m http.server 8877 --bind 127.0.0.1 --directory out
