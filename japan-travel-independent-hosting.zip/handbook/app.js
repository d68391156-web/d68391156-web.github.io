(function(){
'use strict';
const days=window.tripDays,bookings=window.tripBookings;
const money=n=>n.toLocaleString('en-US');
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key))||fallback;}catch{return fallback;}}
function write(key,value){try{localStorage.setItem(key,JSON.stringify(value));}catch{}}
let saved=read('japan-winter-view-v1',{}),selected=Number.isInteger(saved.day)&&saved.day>=0&&saved.day<days.length?saved.day:0;
const done=read('japan-winter-booked-v1',{});
function text(el,value){el.textContent=value;return el;}
function make(tag,cls,value){const el=document.createElement(tag);if(cls)el.className=cls;if(value!==undefined)el.textContent=value;return el;}
function mapLink(query){const a=make('a','', '在地图中查看');a.href='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(query+' 日本');a.target='_blank';a.rel='noopener noreferrer';return a;}
function dayContent(day,index){
const fragment=document.createDocumentFragment(),head=make('div','day-head');head.append(make('div','day-date',`第 ${index+1} 天 / ${day.date.replaceAll('-','.')} ${day.weekday}`),make('h2','',day.title),make('p','',day.summary));fragment.append(head);
const meta=make('div','day-meta');for(const pair of [['当晚住宿',day.stay],['交通预算',day.cost[0]===day.cost[1]?`¥${money(day.cost[0])}`:`¥${money(day.cost[0])}–${money(day.cost[1])}`]]){const s=make('span','',pair[0]+'：');s.append(make('b','',pair[1]));meta.append(s);}fragment.append(meta);
const stops=make('div','stops');day.stops.forEach(s=>{const el=make('section','stop');el.append(make('span','when',s[0]),make('h3','',s[1]),make('p','',s[2]),mapLink(s[3]));stops.append(el);});fragment.append(stops);
const routes=make('div','route-box');routes.append(make('h3','','具体乘车与换乘'));const ol=make('ol');day.routes.forEach(r=>ol.append(make('li','',r)));routes.append(ol);fragment.append(routes);
const note=make('div','note');note.append(make('h3','','这一天记住'),make('p','',day.note));fragment.append(note);return fragment;
}
const list=document.querySelector('.day-list');days.forEach((day,index)=>{const b=make('button','day-button');b.type='button';b.append(make('span','daynum','D'+(index+1)));const title=make('div');title.append(make('span','date',day.date.slice(5).replace('-','/')+' '+day.weekday),make('span','city',day.city));b.append(title);b.addEventListener('click',()=>{selected=index;renderDay();write('japan-winter-view-v1',{day:selected,tab:activeTab});});list.append(b);});
function renderDay(){const content=document.getElementById('day-detail');content.replaceChildren(dayContent(days[selected],selected));list.querySelectorAll('button').forEach((b,i)=>{b.classList.toggle('active',i===selected);b.setAttribute('aria-pressed',String(i===selected));});const nav=make('div','day-bottom');if(selected>0){const prev=make('button','action secondary','上一天');prev.addEventListener('click',()=>changeDay(-1));nav.append(prev);}else nav.append(make('span'));if(selected<days.length-1){const next=make('button','action','下一天');next.addEventListener('click',()=>changeDay(1));nav.append(next);}content.append(nav);}
function changeDay(delta){selected+=delta;renderDay();write('japan-winter-view-v1',{day:selected,tab:activeTab});document.getElementById('day-detail').scrollIntoView({block:'start',behavior:'auto'});}
let activeTab=['itinerary','map','budget','booking'].includes(saved.tab)?saved.tab:'itinerary';
function showTab(name){activeTab=name;document.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!==name);document.querySelectorAll('[data-tab]').forEach(b=>{const active=b.dataset.tab===name;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});}
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{showTab(b.dataset.tab);write('japan-winter-view-v1',{day:selected,tab:activeTab});}));
const budget=document.getElementById('budget-rows');days.forEach((day,i)=>{const row=make('tr');row.append(make('td','',`${day.date.slice(5).replace('-','/')} · D${i+1}`),make('td','',day.transport),make('td','',day.cost[0]===day.cost[1]?money(day.cost[0]):`${money(day.cost[0])}–${money(day.cost[1])}`));budget.append(row);});
function progress(){const n=bookings.filter(b=>done[b.id]).length;text(document.getElementById('booking-progress'),`已标记 ${n} / ${bookings.length} 项完成`);}
const bookingList=document.getElementById('booking-list');bookings.forEach(b=>{const row=make('div','booking-item'+(done[b.id]?' done':'')),input=document.createElement('input');input.type='checkbox';input.checked=!!done[b.id];input.setAttribute('aria-label','标记已预订：'+b.title);input.addEventListener('change',()=>{done[b.id]=input.checked;row.classList.toggle('done',input.checked);write('japan-winter-booked-v1',done);progress();});const body=make('div');body.append(make('h3','',b.title),make('p','',b.detail));if(b.url){const a=make('a','','官方预约 / 信息');a.href=b.url;a.target='_blank';a.rel='noopener noreferrer';body.append(a);}row.append(input,make('div','booking-time',b.time),body);bookingList.append(row);});progress();
const sources=document.getElementById('source-links');window.tripSources.forEach(s=>{const a=make('a','',s[0]);a.href=s[1];a.target='_blank';a.rel='noopener noreferrer';sources.append(a);});
const printDays=make('div','print-all');days.forEach((d,i)=>{const article=make('article','print-day');article.append(dayContent(d,i));printDays.append(article);});document.querySelector('.planner').append(printDays);
document.getElementById('print-button').addEventListener('click',()=>window.print());
const frame=document.querySelector('iframe');frame.addEventListener('load',()=>{try{const size=()=>{frame.style.height=(frame.contentDocument.body.scrollHeight+4)+'px';};new frame.contentWindow.ResizeObserver(size).observe(frame.contentDocument.body);size();}catch{}});
renderDay();showTab(activeTab);
})();
